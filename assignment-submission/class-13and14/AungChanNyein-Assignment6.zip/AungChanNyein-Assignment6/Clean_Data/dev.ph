ja&apos; mhu. jwa mhu.
pi: zei:
mjin: za: gyoun
a- ngan pei:
a- nei a- hta:
kya: mi: hswe: mi.
bo: ma.
mha&apos; su.
ga- gywei:
mwei bwei: pou: hti.
hta min: zou&apos;
cho: za
hpju ba&apos; hpju jo
hsa- ja a- ta&apos; thin kyaun:
wi&apos; tha.
lhou&apos; sha:
gyun: htou: gaun
mi. ga- da woun
oun doun
dha- da- bjan
si&apos; njaun:
pjain be&apos;
kyi: nin:
kyaun: hsa- ja
ou&apos; ta- ra. hpa- la. gu. ni
khou&apos; pain:
kyan jwe
a- je: sun.
lei chun
thin bja
a- njha
zei: kain
le&apos; hta&apos;
baun wi naun lou&apos;
hsei: le&apos; mha&apos;
mhjoun: tha: lhe.
hsa kyu la
a- twin: zei:
than dei:
lu do:
ou&apos; tai&apos;
khan: na:
zoun kan
tha- ma- ta goun
a- mi. a- ja.
ga- doun: ga- dai&apos; lou&apos;
wun cha.
la. gwei:
hta- min: gan
za&apos; win gan:
a- ku ta&apos;
si&apos; ni: bju ha
za ta pei ta
thu do gaun:
a- hsei&apos; ngwei.
hpju hsu&apos;
hpa: ba:
a- ji shun:
mou&apos; cha.
du. ti. ja. wa zo
a- pja me
hein di
mjau&apos; mji
za- ga- chi:
nei tha
kou jei: mha&apos; tan:
hsei: hta.
nou. ei: gyaun:
da- bju&apos; tan
tai&apos; hpje&apos;
u gyaun:
jou: da- ja: kye&apos;
kin ba- lin:
nga- mwei dou:
le&apos; hpwe.
da- ma- tha&apos;
bi. da- ga&apos; tai&apos;
da- bin dain
u: jin: gaun: khe: na
ka- lei:
we&apos; thi&apos; cha.
a- tha: da&apos;
khoun lhwa:
sou: jein ma- kin: hpji&apos;
hsaun: hpji: na
shau&apos; pan:
jei zin: da- da:
kou bain kyaun:
tha- ma ba&apos;
le&apos; lwe
wun po.
hin: mjou:
dha- gya: min:
hpji&apos; njhi&apos;
jan: boun mi: gya.
da- ma.
ni sa&apos; za&apos;
lu ba:
maun: daun: hsan
a- khu. nhe
pju bju ngha ngha
hsa- nwe
poun thwin:
pu. lu.
ou&apos; loun:
in: ain
thi&apos; sa ti
hsa&apos; hta.
sa- moun za- ba:
shei. nau&apos;
tha- main: win
tha- au&apos; tha- oun
pi lo:
chou: hpje&apos;
toun chin dhi:
a- pjaun: a- shwei.
hte dhwa:
pjou: zi:
me hpju:
a- hpo:
chein gwin baun
jin zi. in: gyi
o: za su:
ji&apos; mjou:
au&apos; dou:
mji: zan
su. tei.
shwei bja: kha&apos;
shwei hti:
kyin nge
hsaun: ba:
wa zou ban:
jei gyau&apos;
hsin mjan:
hsoun: ba:
ma- sin sun.
sou&apos; sou&apos;
ma- lwe: ma- thwei
a- che&apos; kya.
le&apos; twe: hpjou&apos;
kei. sa ma- shi.
di: dou&apos;
jei&apos; mjoun
lan: pau&apos;
mein. kya:
chin. gyein
na- bu na- hsa lou&apos;
kha. jan:
bwe&apos; hta.
joun thwin:
e. wu&apos; saun wu&apos;
a- pjou jei
sa- lou sa- la
ou&apos; ou&apos; the: dhe:
za ta ein
khan nain ji
a- na gan
hpjei: bjei: hsei: zei:
htoun: haun:
bjain: ngan:
nha- pa: thwa:
kya: kan
su&apos; swe:
shin laun:
a- thain: a- wain:
ja- me&apos; kyi:
lu ji wa.
wa- laun:
jou&apos; pwa: do.
hpaun zi: ga- nan:
dha- doun:
mjoun si. zi. lou&apos;
wa dha- na ou:
je&apos; hpau&apos; jau&apos;
zi kou&apos;
nan ne&apos; khin:
loun. la. htou&apos;
hpou gyin
a- kya:
a- mhu. ma- hta:
da- zu.
bu: kwe
ga- lan ga- hsan pjo:
kyein: se&apos;
sa wa- di:
nau&apos; pei&apos; khwei:
thwei: paun
a- jwe tin
mwei hau&apos;
jei&apos; hpan: than ban:
thi: da&apos;
ka- lei ka- wa.
ein nein.
hpin. nhei:
ta- win: ta- kha:
sei&apos; sho.
gyu ri lu gyi:
jei zei:
me&apos; ta- ja:
bjou&apos; hsa&apos; hsa&apos;
min ga- la hsaun
a- lou&apos; tha- ma:
bou laun:
a- na loun:
a- khin: thwa:
paun dan htou:
ba ga- lou tou tou
mje&apos; thi:
pja: ban: kha&apos;
nin la: nga la:
da&apos; hpe&apos;
lei&apos; khoun:
jaun: sa:
a- kyan po
tou: te&apos;
za- ga thwin:
a&apos; chi loun:
thwa: gya: htou: dan
bja dei&apos;
ja wi nou:
jwei: che
lwe gyou:
hpo. loun:
sei&apos; khain
ti&apos; li&apos;
kyi: ma:
wa ra. mei&apos; tu. je&apos;
kaun: gyi: pei:
a- hta: a- thou
pai&apos; kyu:
mhaun khou zei:
thwei: htou:
tha&apos; ti. ge:
hsei: daun.
pe: nau&apos;
a- si. a- nga.
ma- kya: gaun: ma- na dha
za&apos; hswe:
mjou: jou:
a- the: kywan:
tha- ma dei wa.
pjei. zoun
ou&apos; thoun
o: ba sa
pa- lin:
wun: jan
sa- gou
koun loun
wa- ra- zein
a- pjin
a- khin
shei: bji&apos; haun: au&apos; mei.
ka- lein njan
oun: nhau&apos; chau&apos;
pjan. bjo:
a- mhwa
hsin tu
joun win
gaun: gyin: zain tai&apos;
di ka- ri
wa. loun:
mje&apos; pwin.
gaun: shou&apos;
ji dhwa:
lou&apos; za&apos;
pa- rou kou
jaun bja:
dha- boun
su&apos; sou
jei laun
pjan. bju:
tan lin:
thwei: hsou:
mja dain
kha&apos; ma- hsei&apos; nei
htai&apos; htai&apos; tan dan
hpju ga sin
nga. min: nga. chin:
lo: ka. da- ma- da
mhja: kyi dau&apos;
pju&apos; thei&apos;
mi: hte.
ja- da- na boun hsai&apos;
a- hte gyi: bje&apos;
lou&apos; the&apos;
a- kha le
si do dhan
nei gyo dha:
shwei pei
htau&apos; pan. gyei:
si&apos; jei: lha.
na- dha- bu.
lu wu&apos; kyaun
pa wa
ku ngwei
jau&apos;kya- sha
mjei za
pei: chei
jei za
le&apos; thwe&apos;
lha&apos; lha&apos;
tha mhu. na. mhu.
lhei ga- hsan
bau&apos; tu
wa nei&apos; za.
jin chaun
jan dain
mje&apos; ma- mjin
kha- jei zi. twin: gya.
mu li gaun:
ja dhi ban:
kye&apos; thein: hta.
bein: za:
a- lai&apos; thi.
hto: la- ba&apos;
a- ta ku:
ni. dan: pjou:
mau&apos; tou
sou si. zi.
dei tha- na
a- mjoun
gyan: do:
za- bu
taun dan:
bi thwa
kyi: baun: te&apos;
ju&apos; ju&apos;
lhou&apos; sha: mhu.
pji&apos; pe
goun: cho:
kye&apos; chi: zu. chi
the&apos; jau&apos;
a- nge a- nhaun:
dwa laun:
dou: ba&apos;
kyaun: te&apos;
a- pja:
ju ni ba sa- ti
ma- da- ra&apos; khaun
kan mji&apos;
pa- lou. ga.
kein: zin dan:
mi: laun ja lei pin.
pa- ri. bo: ga.
ga- da&apos; ngan:
tha- wei
ku. mou&apos; da-
a- mhu. a&apos; htin
a- shou&apos; a- she&apos;
a- mwei hpja&apos;
wa- jin: dou&apos;
ta- thoun dhoun
kan. tha&apos; zei:
nga- pi. gyo
an da- je kin:
shou: pei:
sein: zein: kyi.
go ja
khau&apos; moun.
si jin
gai&apos; pei:
a- tha- bou
a- the&apos; shu
a- cha&apos;
lu zwan: gaun:
nain gan jei: khou lhoun gwin.
pou: lau&apos; lan:
pin le khu
pau&apos; kyo
jo: jaun
a- khwin. a- jei: dha- ma:
a- kyi: dan
kun: za:
cha. gya.
kha- man:
mei&apos; hse&apos;
a- mhwei: dain
me: nji&apos;
si&apos; kyou khi&apos;
sa jei:
nau&apos; kyaun:
a- kyan pei: gye&apos;
ma- thei gaun: ma- pjau&apos; kaun:
tin da
le&apos; khau&apos; le&apos; pjan
the&apos; ka- ji&apos; shei
pi bi dha:
be lau&apos;
sei&apos; tra.
hse mu: jei
kwei. le gyaun pa&apos;
mein: ma- gyan:
sha sa:
ou&apos; shi&apos;
a- ja&apos; lu gyi:
a- mje&apos; pjei
a- kye: dha:
za&apos; sin
poun na- ma
laun kywan:
ta- ja- dhei
hpji&apos; pwa:
jei ein
le&apos; wa: jai&apos;
pjan gyo
hpjau&apos; hsei&apos; mun: lwe:
an. kha- man:
win: mhu:
ka la. bo
za ma- ni
ta- ja: na- khan
zei di
ban: za- ga:
paun: bjan jei
mhjo kho
za&apos; chin:
hpa- mou:
a- wun: a- wain:
ga- ba&apos;
na- mo: na- me.
hpjaun: bja.
chei gyei mji&apos; mji&apos;
le&apos; pu: le&apos; kya&apos;
na- gyi ein
tha&apos; ti. pja.
lin: joun
hsin. ge: hpji&apos; sin
a- jan gyou
nja. nei gyan:
nein. dhan
lin: kyin:
mji&apos; khoun
o: za lhwan:
cha gya le
kyein twe
min: dhoun: sou: dhoun:
bu si baun:
a- njun. kyou:
ma hpa- la
shei: za- ga:
man te&apos;
ba- ja: ei&apos;
jain: bin:
kha- me: do
lan pjei:
shi. zu. me. zu.
gyou pe&apos; ka:
htu: gyun
sha&apos; sa:
a- hte&apos; kyo ka ji
je&apos; kha
che&apos; ta- hpjou&apos;
ka- la- ga cha.
bou hswe:
je: jou
poun pan:
tai&apos; lei jin
twin pe
a tha
a- mi: kou&apos;
hta. kywa.
pa- ri. ja&apos;
moun njin: zi
pou: daun. de:
ta- shein dou:
wu&apos; kyei wu&apos; koun
ho: pjo:
ma- hsou za- lau&apos;
khu. ga na:
poun dhei ni:
thu. na pa- ran ta. tain:
goun sho
a- jan ka jo:
thin. joun
lei. la dhu
tha- ma- tha&apos; daun.
sa- jei: ka- ri. ja
jou&apos; tin
lhe hpe
pje&apos; kwe
za ta pa
a- jaun
a- me: njhin:
hsei: gye&apos;
ou&apos; shaun
kin ma- ra
hpjaun. mhan
mou: gyou: se&apos; kwin:
ma- ha
ko. lan
hsaun: khain:
baun kha&apos;
lei bjei htou:
a- chi: hsa&apos;
a- mhja. ju
a- su&apos; khun
hsu: lei pai&apos;
ta&apos; lan
than mhou
a- hpjei. gan ja- du.
htu. ti.
kyein za mi.
a- hpja: shu:
ba wa.
nei win hpjou: bja.
ne&apos; ne&apos; ne: ne:
pei doun: ta
hpou&apos; tha. ja- hta:
sa pjan
hpjou khwe:
nha dhan pa
pa. lhwa:
a- jei&apos; na- mei&apos;
a- lou&apos; pa:
to: bei&apos; nei.
ka: kye&apos;
pan: hse mjou:
shun. nhi&apos;
me ze&apos;
kya- ngan: bou
pe: ba- za&apos;
su. nu.
jei goun lai&apos;
ba dan
than ba- ja
hsin. kho
tha: dha- mi:
da- we zaun
pe: gyan:
a- chin pau&apos;
po u: po bja:
kyan: ma jei: hsei: le&apos; mha&apos;
kya ja&apos;
ma- ja: pju.
de&apos; khi. na. tha kha
wei la wei:
pou li jou
bin: ga- la: kywe:
la- ha bjin zei:
lan: jou:
hte&apos; pain:
a- kya. nei.
ma na. kyi:
a- tain: a- shei
shau&apos; nu.
pja. gan:
ba- lu: ga- moun:
jou: dou: jwa. ta. hpji&apos;
lei zoun
kou&apos; the:
sha na khwa na
khan: loun: bji.
kha- na.
nga- lin ban:
za- jei&apos; njein:
hi: tai&apos;
da- zi: da- zaun:
a- hsi: a- ta:
a- chaun dha- ma:
za&apos; jan
za- ga- dhwa: za- ga- la
mou: bjan
mein la kan
htoun: ain
lu an: da.
na: zi
lun mjau&apos;
twei: htin
min: mjou: min: nwe
a- kyan doun: njan doun:
jei ze&apos; koun
je&apos; swe:
lei kyi&apos;
zei: lan.
lein gan:
kyau&apos; lhe.
thei nei. sei.
pji: pjei
dha- bo: twei.
a- hpjei. kan
a- kha&apos;
thei gan: pja&apos;
ta win me.
sun ta ni
me njou
thin ga
thin gan: hpu&apos;
ka: joun
pa mi&apos;
u: zun:
a- mu a- ja pje&apos;
a sa- ri.
mou: jan
ga- li&apos; hsa- rin
da- ba de:
a- laun: ga- za:
mje&apos; si. kye
a- thaun: a- hpjin:
sain baun
hti&apos; kyou:
mu. dha wa da.
ja- man
bou za: nghe&apos;
a- sou.
a- tain:
pji ban: shwei
a- thoun: za- jei&apos;
doun: di.
jou: jou: dan:
sa gya&apos; sa ma.
sa- ji:
tha&apos; bjin nju. ta. njan
hta min: sa: bwe:
wi. lou&apos;
le&apos; sa. hpjau&apos;
jou: ja
me: joun
win swe&apos;
ta&apos; je:
lan: njhun
a- mwei za: a- mwei gan
mau&apos; khi. to:
na- jaun pa- jaun
kau&apos; thi&apos; sa: bwe:
jin: ga&apos;
nge gyai&apos;
tai&apos; ja ba pji&apos; si:
pe: bju lei:
na- tin
pou&apos; ga- li. ka.
ta&apos; ma- ha
a: gya ma- khan
taun. din:
a- mje: da- zei
thwei: sou&apos;
mou: gou&apos; se&apos; wain:
si: boun
sa mei: bwe: hpjei
hsei&apos; khan
da- gou do
a- sun: pja.
khou: ja lai&apos;
le bje&apos;
lan: hpoun
le&apos; ja
a- htoun
a- mwei
pjau&apos; kya: si&apos;
a- pji&apos; a- chwe:
sa ei&apos;
za- ga: tau&apos;
jei lou&apos; tha:
le ku li
pwe: ze&apos; mja:
mu ti
nei. mi: nja. mi: lou&apos;
chei mja:
a- hsi&apos; a- pain:
a- than gyaun
bein: zein:
a- thi. zei&apos;
chei mjan
pu&apos; khoun
ta- ja: pje&apos;
sin. ou:
a- si jin khan
lhu&apos; mein.
mei: jai&apos; mei: we
nge mu
pan: zi:
jei lhu&apos;
dai&apos; za- ba:
jwe&apos; hpja&apos; pou:
hpja&apos; se&apos;
jei: chu&apos;
bei&apos; khu. ni
sa: thoun: dhu
ho: pjo: bwe:
ku. ba.
bein: cha.
mhja: jwe&apos;
nha dhan
pu chi&apos;
nhi&apos; loun: bau&apos;
u: tai&apos;
to lhan jei: dha- ma:
nei&apos; dei tha.
kwe&apos; kyo mjin
le&apos; hpwa
a- nou&apos;
chi gywa.
hsa&apos; hpou
a- nei
hpju lha&apos;
jei zei:
mji&apos; ta pje&apos;
wa nu.
mje&apos; nha me.
swe: lan:
lu loun: lu de
mi: gyou: maun: bje&apos;
moun. ou&apos; kha- lei:
kou zi kou ngha.
kyaun: nei be&apos;
gwe: tha&apos;
je: wun.
pje&apos; ti: pje&apos; cho
than bju zain
a- kyin: chou&apos;
me da- lin
le&apos; hsou&apos; le&apos; kain
a- hpoun boun
hsa. dou: gein:
si: nhe:
a- han. a- ta:
pjaun bjaun
chein dou&apos;
pei: za kan: za
a- lai&apos; a- htai&apos;
mjin: tha:
la- ha bjin
si&apos; u. ba- dei gyou&apos;
nhan: gya&apos;
o: pji&apos; ma- kwe:
thwei saun:
mwei: la.
a- njhau&apos;
si: bwa: pje&apos;
mwei. ljo
daun tin:
kha- ji: zaun
hta- sho
da na.
kwe: e&apos;
kaun: mhu.
sei&apos; twe&apos;
a- shin dwe&apos;
moun kya zi.
a ma. gan
hpji&apos; ja. lei gyin:
cha&apos; cha&apos; ja&apos; ja&apos;
thi: za: khan
jau&apos; kha- ma. jau&apos;kya- dhu
po li&apos; bju rou
koun thin: bo:
thein: po
mou: bwe:
a- kywei: pu
than ba&apos; njaun:
koun zei: nhoun:
a- than dwe&apos; jou&apos; shin
jo: ju.
a- the&apos; ngin
thwei: baun chein
bo ja
mi: ja&apos; pjin nja
hsin: the&apos;
ta- na&apos; sa: njan
sei&apos; tain: kya.
kya: le&apos; the:
a- ne: zoun:
hsei: ou:
ja- houn:
mhjo. gyou:
chwei: zi:
kan. gyou&apos; ni
ka rai&apos; ka- ri.
tu a- ji:
pei ka&apos;
me thi la.
za- go: ka- jin
a- nji&apos; a- hti:
wan: nu:
a- hpou&apos;
sa- jin: gain pjin nja
wun: thwa:
si&apos; si:
hou: hou: kyo
ei: hsei:
ta. win: bu
kwe pje&apos;
pa- jan hsa- ja
a- mhu. dwe:
je: dai&apos;
lhwa. tai&apos;
a- jei&apos; pan:
hsa- bou&apos;
a- nin. khan
pja. htan:
loun: la: htwei: la:
a- bei&apos; za
ban da zou:
dha- bjei
thin: gyo:
tha- gaun. dha:
tha dha- na. jei&apos; tha
in ga soun
jou&apos; pje&apos; hsin bje&apos;
hpa&apos; hpa&apos; mo:
man zwe kyou:
a- nau&apos;
ga- lan ga- la:
ka&apos; chwe:
a- hpou:
pja ta
kau&apos; jou: nwe
hsin di gei&apos;
sa- lwe dhain:
hnai&apos; hnai&apos; khju&apos; khju&apos;
jei hta.
jei jin
a ju. thin kha ja. lhu&apos;
pa- khoun: pau&apos;
a- mhai&apos;
jin dha:
kyi&apos; hsan mi:
oun: bin sai&apos;
le&apos; ku: le&apos; pjaun:
a- hte:
thau&apos; to jei
pa- la- wa. e&apos; kha- ja
nga- gyin: bu&apos;
laun: dan: sa: dan:
to: ja. gyaun:
ein. shin
nei&apos; tha- ja.
mje&apos; khau&apos;
sa pei:
na: lhe.
lo: ga- da&apos; pjin nja
a- hwa
kan: gyei zaun. ta&apos;
htun dhwa:
chei za. le&apos; sa.
de. dou:
mje&apos; nha- hpoun:
ta- jwin:
a- pju&apos;
wun: za za- ba:
a- jei&apos; kyi.
nei je&apos;
a. ju pa. boun
za- bu ji&apos;
pwe: lan:
thwei: kyaun
la. bji. nei.
pjo: jei: hsou gwin. shi. dhu
oun: ga- ne:
a- lou
pe: ga- di ba
mi: nei
lhwe: pjaun:
si&apos; u. ba- dei
khwa ji si:
pja ka- la&apos;
thein gi
ka- la- ga
ma tu. ga ma.
lai&apos; sa:
a- hte&apos; si:
za&apos; paun: gan:
htain: mjin:
a- jei: koun
hpjei bjo
lhei te&apos;
nei mjin.
kyou: me. kyei: nan:
ju. ja. pai&apos; htwei:
le&apos; sa. tha&apos; to.
a- thei: a- hpwe:
kyin. thoun:
hsa: mji:
nei&apos; ban zei:
a- kywei: htu
hswan: do sun.
wu&apos; pju.
kye: gin:
i na:
sei&apos; ba- di:
kyu: jin
ka&apos; ta ra. thin chei
wa nge hta&apos;
ti. hei&apos;
cha: ja- ha&apos;
swei. zwei.
moun. kywe: dhe:
me: ne&apos;
sei&apos; shei le&apos; shei
le&apos; we: ji&apos;
htwei: in
lou&apos; hsaun gye&apos;
pau&apos; pwa:
sein: za: nga- pi.
pjin: hou&apos;
chei kya.
mjin: a:
tain bin
pjo win nain zwan:
hsa- ja lei:
kyi dau&apos;
ba gi
twei. ga- ja
pja. jou&apos;
jou&apos; poun
hsi zein se&apos; ku
bju&apos; thai&apos;
pou&apos; gou zwe:
ka- nwe. ka- lja. lou&apos;
lhwa. za
dha- gou:
poun nhei&apos; se&apos;
hta- min: gyain.
kye jei mhou&apos;
ja za- hta ni
ju: ju: mai&apos; mai&apos;
a- htan
kyi: chi
min: kou ka
sa- jwei: bau&apos;
jin gwin
kyan: khin: zei:
a wa tha.
za- ti ri jou
hsa&apos; pja mhoun.
hpin bu: daun: htaun
hpau&apos; the pei:
kywe&apos; nou.
pa&apos; ti: cha.
thun: laun:
shin than
a- twin: a- pjin
nau&apos; hpei: ou:
wi. ba ga. wu&apos;
le&apos; hswe: boun:
pu tu tu:
a- mo: sei.
pja ji: pja ja
ba- zun nga- pi.
a- shin tha- khin
mo to
si: cha.
lou la:
e&apos; u. ba- dei
a- pjan
ji da- jo:
lu nei mhu. a- hsin. a- tan:
hsu. la&apos;
mji dhou. mji nja
the&apos; zou: shei
a. thu. ba. shu.
wi. gyou
hse: hsou
pan: bu&apos;
ga- bja hsa- ja
le gyaun: dhan
a- kyaun: chin: ja
taun ka- thi&apos;
da&apos; ngwei.
pa- lin zin: ngwei chei
lan. hpja&apos;
nga- mai&apos; tha:
bou&apos; ou&apos;
a- jin: mhjou&apos;
mje&apos; mje&apos; se&apos; se&apos;
lei thun
sa- jin: dain
hsou&apos; kan kan
nja. dwin: gyin:
lei boun:
ban nhoun:
kain: goun
shwin mju:
nan daun:
o: za shi.
maun nha- ma.
mjau&apos; ein do
hpja&apos; sa: ja&apos; sa: lou&apos;
ga- ba. je&apos; tha&apos; mjin:
the&apos; the&apos;
wun: ne: pe&apos; le&apos;
a- khin: hpji&apos;
a- nu. zei&apos;
a- pji&apos; pei:
a- ja. gau&apos;
ku: cha.
a- kyin lin ma- ja:
lei: bjin lei: ja&apos;
gwin: dou: hpa- na&apos;
pjo. dha:
sa- pa- rin
da- gaun gywe&apos;
lu bjou hain:
than gwe: kyaun: du
za&apos; jei le
a poun
ga- za: wain:
a- mjan ja- hta:
kyoun: thwin:
lan: pja&apos;
tan la.
kyan. dou: mou: zin:
thu dhu nga nga
sho. cha.
mje&apos; kyo: tin:
zou: ga- ne: za&apos; kha- ne:
mai&apos; jain:
chei dei&apos;
kan khei
kou le&apos; nhi: nho
jin: ne&apos;
a- ja. kye&apos;
njha ta
khau&apos; chou: chou:
na- jin: ou&apos;
kyei&apos; mhei&apos;
a- ka dha:
khwa pje:
ji. jwe:
lai&apos; pwe:
le&apos; ja:
lei hpi. a:
au&apos; chin:
nwa: za- gyin:
nei chou
a- toun: a- joun:
ga- nan:
si: kan:
thun: dhun:
sein: shwei shwei
thi&apos; khwa: ji
da- bu sa:
ka bain
a- jan a- ta:
ma- ha gi ri.
ei&apos; hpan zaun.
doun: za&apos; lhei
kya: thi&apos;
ji za- ja hpji&apos;
thwei: nu. tha: nu.
nhou&apos; mhu. pjin nja
nga- man: daun
a- khan.
pa- hta- na
ba- dein bou
hse gyou: hse la.
a&apos; koun
na. kan pa- ti.
pan tu
kha- lei: zei&apos;
thin gan: lha-
mje&apos; si. mhei&apos;
sa. loun:
sin ti ga- rei&apos;
mhja: u: poun
a- kyaun: pju.
a- chei pje&apos;
ja hta: gye&apos;
a- hpu:
ban da&apos;
ba- ra- bwei
lu boun
dha- ga- da gan
ge bau&apos;
shwei din: ga: pan:
chaun: hsou:
hsei: kya.
au&apos; tan: kya.
a- thoun: a- nhoun:
kyaun mje&apos; jwe:
le&apos; kha- na hpa&apos;
a- bi. dan
kyau&apos; tan
tou li mou&apos; sa.
chi&apos; tha:
shei: bji&apos; haun:
nga- khoun: ma.
lu ja thwin:
le&apos; chi&apos;
bjain: chi:
ka. bje&apos; ja. bje&apos;
shu. mhjo
chei gyin: kha&apos;
a- khan
lhain: dou
le ja chaun: mjaun:
wi. ka&apos; pa- na
lei lan tin
ei&apos; pjo
le&apos; jou:
za- ga:
hpjou hpje&apos;
chin: loun:
tu: mjaun:
shaun ta- khin khwin.
a- ngou
a- hpjei. ka&apos; ta:
jan boun ngwei
u. dan: kyu:
sa dai&apos; thi&apos; ta
hsi gyi ei&apos;
hta&apos; ta- ja
jou: dou: jei&apos; tei&apos;
si: dou&apos; hpan
the: gyau&apos;
ei&apos; chein
za- ga- din: hsou
pa ra- mi
paun: lai&apos;
a- ei:
ka la. wan:
tha- ke. dhou.
kyaun mi: du
tha- ra- hpu hsaun:
pjein: thwan:
kya. ban:
tha- min gyou
hpan jei hsou:
lu dwin gye
e. gan hsain:
a- lou&apos; hpji&apos;
than khi&apos;
a ka dha. zou:
o: za ti
thaun: dhaun:
wein njin
khau&apos; kyei:
aun mjin
shaun sha:
a- kyo: hsain:
du bei na bei khan
pou: mwei: zou&apos;
tain aun
than bja&apos; lhwa.
ta- din ga.
htou: moun.
lin dha:
jaun: we
lau&apos; lau&apos; la: la:
mou: kyein:
nhin: kwe:
hwe&apos; sa
kou loun: bo mhan
sei&apos; jo: kou ba
ta&apos; u: ba- lu: ba
pa- jin:
lu nge
za- ja:
kyu: kyo ne htain dhu
ma- chou ma- chin
ka- ji no: dhan
le&apos; wei za
hsa- kha:
aun dha- bjei
jei lhe. thin.
lu lou&apos;
nge nan me
htan: te&apos; dha- ma:
i: pa
chei&apos; tei&apos; tei&apos; pjo:
ni. dan:
hsoun: ma.
kywe&apos; twin:
sa mu ga.
jan lou
min: me. tain: pji
mi: ja&apos; pein mi: ja&apos; chau&apos;
a- thei: a- mhwa:
khan. khwe:
man hpi
ja za- dha&apos;
hpwe: nu.
a- ne
hou&apos; ke.
jei nan zi
ne za&apos;
le gun ja ne&apos;
za bo li
za- ga: hti&apos;
a- ka a- jan
u. pe&apos; kha pju.
hpe khwa
jei dhein
wan: gai&apos;
pa- le: bau&apos;
jan saun
thi ga ji ga
htein hwe&apos;
in: dhwa:
lwan: bja: lwan: na
hpin dain goun
khain: me&apos;
a- hpjai&apos; ne&apos;
ba- wa. pjaun:
ja gwe&apos;
ja za- wu&apos; kyin. htoun:
wu&apos; twa:
maun: zi: le&apos; hpwe.
thoun: daun. ain gyin:
ba- ra- bji&apos;
naun ba- wa:
pe: gyi:
dha- be&apos;
le&apos; lhe. thin.
chi&apos; chi&apos; chou&apos; chou&apos;
nhou&apos; kyun
di lhain:
sa kyaun:
a- tha: njha&apos; moun.
lei tei&apos;
sa- tu. ma- du
dha- bo: tha- jou&apos;
wa dwe&apos;
pa&apos; loun:
a- tei&apos; kau&apos;
che&apos; ka- li.
hti. ga- bau&apos;
kye&apos; tha- jei gan:
a- the&apos; hte&apos; hsoun:
je&apos; kan: gyou:
ja- han:
ba- zun gyau&apos;
chau&apos; pau&apos; ma.
mi: zo
poun hswe:
sein jei
a- ke: hpja&apos;
lei gyin te&apos;
than bja&apos;
tha&apos; mha&apos;
sa&apos; ku: ma&apos; ku:
tha- khou:
nei&apos; tha- ja.
din bjei. kya&apos; pjei.
thu ri. ja.
goun thein
a- khan. to
hsi: thwa:
we: sa:
da- zau&apos; kan:
pjin: ma.
hsaun. aun.
ta- jo
hse&apos; kyei:
a- hsa bjei
pjan ga ha&apos;
mjein she&apos;
khe: jan: mi: kyau&apos;
jei kain
dha- ba wa. pau&apos; pin
tha- chin: gyi:
dha lhjin
ko pi
jei&apos; tha bin
lu&apos; mjau&apos;
hsei: ou: bou&apos;
ja nhoun: bjei.
chwei: zei:
kyau&apos; sa dain
ju&apos; twa.
swan: ji
ta- moun.
ei&apos; ja da.
jei boun bain
ju pa. ni. ke
do: na.
wu&apos; htu. dou
kyou: wain:
a- jei: pain
hsei: dai&apos;
ti. di.
se&apos; lhei ga:
in chai&apos;
a- lou hsan da.
shwei daun
mou: mhjo
le dhi:
khe: ma. hpju
than gyou: za
dha- gya: jei zin
ka hswe: bau&apos;
sai&apos; khwa.
cha. boun:
nei win mou: gyou&apos;
a- thin chei ja. ka&apos;
hsi bjan
jei zoun: jei bja:
dha- dwei:
mein: ma- gou
ngu tu du
le ba- du
ma- chi. tin ge:
thwei: wei:
a- lhan: kwa
hpa- ja: kou: zu
a- njho mi.
paun: tin
sa dain
chu na dhe
sa di: mhu:
na da shi
do li kyou
nge za- jin:
ou&apos; o thaun: nin:
khou mhi:
si&apos; pjain
jo: loun gyi
a- hpjo jei.
njou. mhain:
na- ban
se&apos; kya hpjan.
a: shi. pa: shi.
me mji
za- lou&apos;
hswe: gya.
dou: ga- ne: dau&apos; kha- ne:
mjei bo
a- mjou: a- nwe
a- tou gou&apos;
chei zin:
ma- kaun: da- jaun:
ma- ei
ma- gyi: pa- ni
tha khwa
wain ja le&apos;
hpau&apos; lou&apos;
twe nhe:
a- mja&apos; htou&apos;
kha- jin:
thwei: bu lei. kyin. gan:
hte&apos; we&apos; we&apos;
a- hpji&apos;
za- do tai&apos;
shein: hsa ja
lei lhe.
sein: ko:
a- htu: dan:
bou&apos; da. tha- ra- na. bin
na- nga&apos; jei&apos; gya.
ou&apos; khwe&apos; hpa- ja:
hsei: bjin: lei&apos;
a- mwei: hsaun:
za- ga: bjo: kyi: nan:
hsan njha
tha- na. jou&apos; pa.
u jain:
mu wa da.
hsin. bwa: thin dan:
mjei ja
a san i
kwe&apos; na pou:
hpou&apos; win
nau&apos; nei.
u: htan: pe. htan:
a- kha. kyei: ngwei
sa- khan: cha.
o gyi hi&apos; kyi:
laun kyun:
ja dan zei.
lei bou
pan: wu&apos; ji
saun. thoun:
pin jin:
ta wun me.
jou&apos; hsin. dha- dan
a- chein ja.
ljaun: se&apos;
sa- lwe
mjwe&apos; kya:
a nan da- ri. ja. kan
kywe&apos; tha:
hsei: htou:
gan da ri
nga- mhoun
kyau&apos; swe:
wun gyi: gyou&apos;
jei ze&apos; hsoun
lu: jwei bo
nei. gyin: bi:
a- kyi
mei&apos; hsoun bwe:
le&apos; hpjau&apos; ti:
ni. ba&apos;
po htun:
a- pjoun:
mjin: bwe:
a- chou&apos; tha:
te li hpoun:
a- twe&apos;
shi. khou:
pa da- re&apos;
hswan: hsan zein:
ta- the&apos;
mje&apos; nha- me:
na- bji:
nan: shou&apos;
la- me
ta- u doun. zin:
we&apos; kya.
ka- la&apos;
a- ngan.
koun zoun hsain
paun: mou:
jei le
sin: ljin:
hswan: gan pin.
ki. mi. la. bei da.
nan gya:
jau&apos; jou: dan
a- thei:
to: mha:
pa- jei&apos; pan:
o gye hi&apos; kye
chi doun cha. doun hpji&apos;
nou. bjin:
mjau&apos; lhei ga:
ei&apos; mhoun soun mhwa:
chun mja.
hpin lei:
htou&apos; lou&apos;
la&apos; ja: la&apos; ja:
nwa: gyau&apos;
a- hpan ban
a- cho:
da- nhaun.
sa- lun
ba- za&apos; dha- din:
pe&apos; pin:
a jou&apos; bei&apos; da.
a- su. a- thin:
su. li:
dha- ga- ji&apos; tou
kya: dha: mou: gyou:
na- hpa gyei:
tha- ma di. khoun joun:
a- si&apos; khan
a- thi. mei&apos; hswei
mei&apos; tha- ka.
san da. ku. ma ra. za&apos;
nei nain
mje&apos; jei jou boun:
thu&apos; thu&apos;
mjau&apos; mwei:
lau&apos; lhwe.
a- kyo: mje&apos;
za. du
pjei le
dha- gyan a- mjau&apos;
nhan za: pjaun:
ein me&apos; mjin
han hsaun
lei win bau&apos;
pwe: zei: dan:
loun: ban:
le&apos; nge te
kho: bjin
a- thau&apos; a- sa:
a- koun khan
nja loun:
le gou&apos;
taun boun ja boun
a- kyaun:
da- ra-
saun. shau&apos;
pja&apos; pja&apos;
wi. te&apos; wi. sa ra.
a- lou me.
kha: kain:
pjou: jan:
a- kha. me.
khun nha- je&apos; tha: dha- mi:
an ta- lin:
than bju
da-ra&apos; htu.
kyun do
sai&apos; sai&apos; sai&apos; sai&apos;
po. shu&apos; shu&apos;
wa. gyau&apos; wa. gan
mei&apos; ka&apos;
ke. hwe&apos;
khwe: sei&apos; ku. sa- ja win
a- jei: lou&apos;
tha- jei thi&apos; ta
hpei&apos; kho
a- loun: lai&apos; a- khe: lai&apos;
jei mou: chou:
pwei: gain:
a- khwei
shan. tan. dan.
nei. shei je&apos; mja:
jou: ma.
goun min:
thau&apos; kya gyou
thou thei&apos;
ngo nge&apos;
thi: daun hpu&apos;
wu&apos; loun
so: bja
lin ja.
ta- hpjin: bjin:
a- twin: za- ga:
kyi: zaun. kye&apos; nhin
ni. ba&apos; khin:
than dei
a- noun nja ta.
ku: gyi than: gyi
a- nu. mju
pa- ra- ma&apos; hta. ta- ja:
a- kyou: zaun lou&apos; ngan:
khain gyei:
u&apos; hta. htan
sha shei
bi za- na
pein: ne: jaun
a- hte a- lei&apos;
a- hsin a- pjin
mjou: zei. cha.
than dou than za.
wa- gyei&apos; lein
nji ma.
a- chi: nhi:
jei: jei:
au&apos; chin: za
sun. khwa
mei&apos; tha.
hsun: thu&apos;
goun se&apos; ku
shou&apos; htwei: pwei li
da- da: shin
naun do
mji&apos; hpja&apos; hsei:
ou&apos; hsaun:
ka tha pei:
cho chu&apos;
bau&apos; lau&apos; njou
lwan: hswei:
sha- zaun: gyin
hpoun: doun: loun: doun:
dau&apos; dau&apos; kye:
u gya pau&apos;
kyi: dha: jai&apos;
mi: htwe&apos;
bi kya:
a- kyai&apos;
kye&apos; u. gou: mwei
la&apos; pei&apos;
htau&apos; chin.
di ga. nhi&apos;
che&apos; kywei
nge baun:
ka la. na- ga:
jin gyo:
mei. jo.
gyi i. pa&apos; ta. mja:
chei cha.
mein ma- gyi:
wun: khain
chin njha&apos;
ba- da: dain
da- gaun:
pa- rei&apos; mhun:
lou&apos; hpo lou&apos; hpe&apos;
ta&apos; twin: poun kan mhu.
cho: mo:
dha- zin
lan: shau&apos;
ji&apos; tan htou:
a- le: a- lhe
a- twin: zaun
ma- hsu: ma- je:
kwei kwin:
ka ma- bain
tha- jou&apos; dha- gan
le&apos; hpja: hswe:
hpein: nhwe: ga
kha- mja
ein da- rei shin
jou&apos; ti.
tha: pje&apos;
a- ko di jan
nha- loun: bju:
su: zu: wa: wa:
lu bjo: thu bjo:
ga- dou&apos;
tun. shoun.
au&apos; tan: za:
wun zaun mhu.
twe: laun:
wan: nu: za
nge dhwa:
a- nan. a- the&apos;
za&apos; thwin:
ein ma.
a- she&apos; a- kyau&apos;
dha- din: kyi:
bin: ga li
tha- jei
khei&apos; da da- tha- ka.
mjan lu
gyin: zein:
tou zi. tou zi.
da- dwei:
kyaun win
si do
a- kyaun: thi.
a- ma. a- za.
a- twin: ta ja
kye&apos; tha- jei zaun
hpa lu da
ba. da- bjan kya: da- bjan
nau&apos; htain
hpe&apos; twe:
ta- man: nhou:
a- pji: a- pja&apos;
mji&apos; kyou: in:
dha- zin min:
ba- ga- du:
jo: swe&apos;
dha- de&apos;
sa- jei: dan
hpja&apos; htou: njan
min ga- la u:
ba ja
nga- jan. gaun: dou
kha- lou&apos;
tha- jei
pjan pjaun:
lu ma- ma
ga- zi. ba&apos; tin
mjei boun dhi:
gyun: dhi:
hsin ga&apos;
kyi: gan: taun: mhau&apos;
jei ba: se&apos; ku
sa- jwei: dan
a- lja: goun
a- sa. toun:
ma- kya ma- tin
a- chein ma- jwei:
wan: pje&apos;
mje&apos; nha- mwe:
za- ne&apos; ka. za&apos;
da- ma. thei na pa- ti
pa- lin hsei: mou:
wi. wa ha. min ga- la
thin. ngwei
shan: gyei chei
wa- ran:
hpoun: gyi:
le&apos; sa: chei
pjo. bjaun:
ba- be:
a- thi. pei:
da- zei&apos; toun:
mei mjou. ban:
pin bwa:
a- sou&apos; a- pje:
ga- dwin: kaun:
pjo do hse&apos;
we&apos; kyein
pai&apos; hsan sho
hpja: na
a- hsoun: tha&apos;
nha- loun:
pjaun: a- chin:
shwei dou ngwei za.
gu. din ga.
da. au&apos; chai&apos;
thi&apos; tan twe&apos;
hta- ma- jei bu si:
a- taun.
a: dain: ja: dain:
kou. hpa dha
a: nge
than be&apos;
la. bjei. nei.
a- chau&apos; a- chan:
na: cha.
jwa jou:
a- the&apos; win
tha- ma a zi wa.
in dain:
tha- min le bjan kyi.
a- che&apos; a- le&apos;
pa man ga- nei&apos;
mjau&apos; htain
joun: gyein:
sa- khan: htaun.
pjun htwe&apos;
ho. jan:
i&apos; nei.
lu mjou: zu.
thi&apos; htou&apos;
lei hta.
o: ba
goun: jou&apos;
ja. tha- min gyi na&apos;
a- tu
paun bou: khu.
nhou&apos; pei&apos; kha.
u. ba- za
pa- lwei
a jaun te&apos;
thi&apos; cha.
mhaun me:
thou&apos; da bou&apos;
taun bu za
sei&apos; nau&apos;
a- chei shin
si: wa: kai&apos;
kyein bji&apos;
bi. da- ga.
a- ko hsai&apos;
a- kin: pa:
gyou du.
a- lan be
tin pou.
we&apos; khau&apos;
ain htun:
khaun: bei&apos;
ta wun
ba ta min
dhi. nau&apos;
nan: kya.
mai&apos; mha:
pei mji.
kya khou
mi: le
wan: gwe:
a- na a- hsa
win jou: zun:
wan: sho:
ma- kya: wun. ma- na dha
to lhan jei: nei.
hsa&apos; pja mhwei:
khwe: sei&apos; ku. pjin nja
u jaun ngan: bja:
ga- ra wa tha.
bja ka- roun: kyan:
hsei: si&apos;
pja di. ha
maun: htaun:
pa- lu tou ni jan
du wun
si&apos; mhu. dan: haun:
da rai&apos; ta
njaun zi: kya.
pein: ne: gwin:
nga- pi. daun:
a- mha&apos; kyi:
pai&apos; cha.
pji&apos; pji&apos; nhi&apos; nhi&apos;
swe: gyou:
pan htwei bjo
boun daun
kywe: go:
min: bo:
chi gwin jai&apos;
a- ji kyou thau&apos;
chi zoun pji&apos; win
hsei: lai&apos;
ngan: do gya:
kyaun ga- lei:
tei&apos; ri ko da
thin: gyan te&apos;
se&apos; tain
a- nan.
mi: gyou:
jin. njaun:
hsan loun: di:
a- hpji&apos; hsou:
a&apos; mhjou&apos;
sin kye
a- the&apos; thwe: gyo:
kwe&apos; ka- ra
tha- ri ra. da&apos; to
a- na: pei:
sha: ba: za- jei&apos;
lei dhan pji&apos;
thei da- ban the&apos; ta- hsoun:
khe&apos; htan
o: wa da. gan
ka&apos; lhu
sun: pei
a- kyan mjau&apos;
a- kan:
maun: ma- le
za- ga- wain: hpwe.
kou: dha:
pa- hta- wi da&apos;
pa- ne&apos; the:
ra- khain
lhe. gin:
nou. lein
a- twei:
nga- mhan kan thai&apos;
sei&apos; so:
tha: khwe:
za- bwe:
le&apos; thin.
a- mjin mhan ja.
na ju
doun la- ba. ta- ja:
ngwa: ngwa: swin. swin.
nhi&apos; hsan: ta- je&apos;
na- win: kyei
thin: gyi&apos;
chi bu&apos; tain le
a- mhu. zaun
gan di.
nga za:
mje&apos; lhwa cha.
mha&apos; mi.
a ga- dwin:
a- the: nha- loun:
nan mji
kha- ji: kyoun
hpa- joun ga:
mi: bjin: tai&apos;
dhi ga- lau&apos;
ba- laun hsu
hpwe. bwe. nwe. nwe.
poun do hpa- na&apos;
thi koun:
a- khau&apos; shwei
u. dan:
tan ja
le&apos; li
mje&apos; mhan: tan:
kou&apos; kyi&apos;
bi ei baun:
dha- gya: moun la
a- khu. na.
aun bwe: ja.
ma- kin: ja ma- kin: gyaun:
ta- lin: chi: kha
a- mun: a- man
thi ha. ja za
na: gya: bjin: ka&apos;
nhou&apos; hpjei sa mei: bwe:
lei au&apos;
ka ja- gan mjau&apos;
bei: jan
pa: lja:
pau&apos; ka- ja.
bja&apos; pji.
kou wun hpje&apos;
pu li
ga- do.
bou&apos; a- hpwe.
doun: wei:
htein chan
ma- jou ma- thei
hsei: jei: ba- gyi
tau&apos; te. ka&apos; ka&apos;
nei. gyin: bjan
hsan: thi&apos;
mhjei: she&apos;
na: ei:
mje&apos; nha- zein:
hsin shin
poun na- jei&apos;
a: ljo zwa
nga- pou&apos; thin
in ga ja&apos;
kha- lou&apos; tai&apos;
hsa: gyin:
thaun tin
mjein. mjein.
wu&apos; sa:
a- chei&apos;
the&apos; win
jin na
a- ni:
a- sou. htou:
mo gun: dai&apos;
a- hpjin:
ta&apos; ne
lu pji
a. hti&apos;
koun: lan:
a- hte&apos; au&apos;
dhou. di: ma- hou&apos;
koun lou&apos; hse&apos; hsan jei:
si&apos; ke:
nou. boun
shu shai&apos;
pa- le&apos; hpaun:
poun du ku:
ou za
ba la.
lu gyan:
a- hti&apos;
thwei: lhu ban
a- hsou a- mein.
ju pa joun
hpjaun. gye&apos;
na- hpa gyi:
a- ne&apos; hpo
kan gyi: kan nge
nhi: wa- laun:
pja. tha.
nga- jou&apos; gya- bwei.
me&apos; mun
koun zi
a baun
tha mou mi ta
a- we lai&apos;
lei: gyou: gyi:
jei&apos; jei&apos; jei&apos; jei&apos;
ja. gaun: zei
ta- hsi&apos; tha khwa:
htun doun:
ga ma wa thi
gya: bau&apos;
hsi: gyou
nei&apos; sa. thi la.
mou: dhau&apos; kye
ba ba nja nja
da&apos; si: ba&apos; lan:
la. le joun za- doun:
wu&apos; kaun: sa- lha.
pjin. nja&apos; to
a- njun.
hse. nha- kyou:
wi. tha kha
a- hpe&apos;
nga: gyi: an ba&apos;
ba- he&apos;
in ga daun.
dha- gyaun tai&apos;
koun gyo:
chin. twei:
bju ha khin:
shwei hpa- la: jaun
swe do
mjin. mje:
ba ja na- thi che.
te&apos; kywa.
ka- wi.
pa: na&apos;
tin gyi:
lhain: si:
te: htou:
kun hpa- rin.
ba- bu. hsa- ja
kyei: ka- la:
mei. mha:
than boun:
lou&apos; ngan: zin
tha- min ma.
tha- jei nwe
zi wein kywei
san da- ja:
swa laun swa laun
ko. la&apos; ko. la&apos; thwa:
thau&apos; jaun
da&apos; hsin
ma- ei&apos; ma- nei
a- chou bwe:
u. pa
hpwa: be&apos;
thwei: ei:
nei. dhin. nan dhin.
pau&apos; si
pa- kein:
hsain ja
a- kha mhi
ta- thwin dhwin
ja- di.
thi. mi
chei goun le&apos; pan: kya.
chou&apos; jou:
min: lja
pjei. shan
ra&apos; tha. nhi&apos;
a- chei ma- lha.
za&apos; hsaun
za- ja- tu.
boun ma- hou&apos; pa&apos; ma- hou&apos;
nge bju
thein tha- mou&apos;
a- nhou&apos; a- thein:
pou&apos; ga-
mje&apos; shu.
sa&apos; su.
pei&apos; swe
le khan
le dain
wun: mhan
nha- kou. da- zei
ba- zun za
ga- hei
nau&apos; khan ka:
ta- hpji&apos; le:
za&apos; na
thi: khan
da- ma. ban da ga ri ka.
pa- li
nei&apos; za- ba&apos; hsun:
hpaun: kywa.
