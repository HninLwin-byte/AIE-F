te&apos; te&apos; pjaun
ka&apos; pi.
shoun. me.
njhin: ban:
mun: man
nge mji
sha sha hpwei bwei
ba- bjin:
u. ma- kwe: thai&apos; ma- pje&apos;
a- si&apos;
jei kya.
ma- hsou&apos; ma- hsain:
ha. gwe&apos;
mein: mu:
ke ma.
nin: ne
ka. gyou: da- za
hsun: gyi: laun:
wa kyin. gyin.
kou&apos; he: na
ni kyin gyin
a- lou tu
kein: jin:
mi: dain
wei. le gyaun ba&apos;
za- ga: bjo: kyei: nan:
a- chi&apos; u:
a- the: kaun:
nja. gyi:
chou mja mja.
mju mhe&apos;
hsei: hpo
a- ke jwei.
a- lai&apos; kan: zou: ma- thi.
je: be&apos;
a- khan hsei:
khwa. gwe&apos;
tha- lin: daun
a- kyaun: mu ga:
a dhi:
ei: da- mja.
mhi we:
pein da&apos; hta.
ke&apos; ta- lau&apos;
hpa. gin
kyo. kyan:
kaun: za:
jan: than:
swe: hsou
ka&apos; pa:
tou dou htwa dwa
khain loun
shwei zain:
jou&apos; wa da.
bu. dou
pwin. lan:
mje&apos; hsan gye
thou: di:
hpau&apos; chi
ta&apos; hsin
ja dhi u. du.
a- kya: ka&apos;
ka- la- hsin
a- si. she&apos;
kun: daun gain
da&apos; thwa:
khin: nhi:
laun: daun:
me&apos; kun
a- moun
nau&apos; pjaun
bou kei
jei gye&apos; ei:
kyin hpo
sa bjin
lei gyo:
jaun pju. tha- lwin
mje&apos; nha- ge:
a- kha lun
a- nhou&apos; le&apos; kha- na
si man gein:
ja: nou:
njhou: nge
jwe&apos; tai&apos;
moun. moun. nje&apos; nje&apos;
khwei: l ja:
htu: dwin:
lin ban:
ta&apos; ta&apos; swe:
sa- mjin
pji pa.
khwei: ju:
ba wa. jou&apos;
na ra- ni
a ma. gan pji&apos; si:
chu: dhu
kan: mjaun dei tha.
kyei le
hpa- ja:
jin ma. me: jain:
la&apos; sa:
mwei: je&apos;
ge laun:
nga- hpoun: zei:
pe: zi
sa gyan mha&apos;
pa- rou tin:
an da- re
a- chi to
lo: hso
dha- din: thoun: bo
tha- jan za ta.
mjau&apos; lou&apos;
sa si sa goun:
pji&apos; zoun
pei dan
a- mja&apos; to gun
mou: jei gan thin gan:
a- kyo: hta.
kya&apos; ngan jei
a- kya&apos;
lun: kyin
a- hte bje
hpja&apos; pain:
ou: ein htu
le&apos; kha. sa: na:
khan da&apos;
u. hpaun:
kein: khan:
pjan tan dan nan. tan. dan.
mi: bwin. thwa:
jein gin
maun nhan
le&apos; thwei:
jan: lwei.
chei&apos; pei&apos; tin da
ja hu. daun.
ga- bwi:
hpjau&apos; hsei&apos; mje&apos; nha thi&apos;
nhi&apos; chin: min ga- la
a- hsi ji&apos;
a- khin: dhwa:
lo: gu&apos; lou&apos;
le gwe&apos;
a- nei&apos; sa.
in ga. tha- ma. ou&apos; sa
u. pa- ma a- lin ga
ga- dou:
a ha ra.
jwe zu:
jei: ja
a- sou. pou&apos;
sho: zaun
pin le zoun:
a- sa tin
hpoun boun
thwei: hsa
ein ja mha:
mji&apos; twei:
lu jou dhei shin jou dhei
be do.
a- ja&apos; be&apos;
a- tou a- sa.
shin ma.
shein zo
da- bu&apos;
pe: da- le&apos;
lei lan pji&apos;
pwe: tou:
pe&apos; ka- la
maun: njou
rei di jou te li sa- kou&apos;
hsa- lan pei:
thi: bja: hpu&apos;
na- daun: gyou:
na- ga- ba ri
shai&apos; kyi: ngin gyi:
a- shun:
a ri. jan
lu jei: pja.
na- lin bjan
sa- khan: thwa:
nha nu.
ga- hei hse&apos;
le&apos; ma.
wa. lin
nhi&apos; shaun. nhi&apos; sha:
o le:
kye&apos; tu jwei:
tha&apos; pou&apos;
a- pje&apos; a- si:
ou: dein: dhe
lei hpan: dan: si:
dwei: bo
ki. lei&apos; hta. do: dha.
au&apos; chei
ku: than:
gyou kya.
kha: ga: thi: dhi:
hpwin. lhi&apos;
hsa&apos; ko. la&apos; ko.
mou&apos; tain
lei. la
mje&apos; nha- do hpwin.
le zi: kyou:
kyo nja
chan: ei:
thu gaun:
nga- hpe aun:
tu. pa.
kha- no ni kha- no ne.
mi: gwe&apos; na
hpwa: mjin
pjin njaun
koun ja- hta:
hta- nje&apos;
ein me&apos; pei:
tha- chin: gan
mjou. thein: ta&apos;
se&apos; bein:
hpau&apos; tan
twei: loun:
a- tan: bain hsa- ja
na- gan na
ma- ra- man
ou&apos; htou&apos; kyou:
a- kye gyou&apos;
taun ga- ban:
a- jei&apos; da- gyi. gyi.
kyan. gyan. khan
ba- doun:
pa- lu pjan
ga- ja-
a- ji: gyi:
khi&apos; shei. pjei:
moun. kya gwe&apos;
tain: mhu:
ba- daun: le
a- pjin ba- wo:
lan: u: dai&apos;
htu&apos; ain: na
jwe&apos; hte
na- nau&apos;
tha: gyi: ma- ja: gyi:
le&apos; tou
ou&apos; sa
le bo pei:
zei: gyou&apos;
da&apos; lhei ga:
chei bji&apos; le&apos; pji&apos;
e&apos; kha- ja thin cha
tu&apos; ti: tu&apos; ta pjo:
hpaun za:
pa- la ja
bei: ban:
jei baun
mi: ga
hse li kyei
pou&apos; ma.
shein: shein:
jin boun dha:
nan be&apos;
ka. za&apos;
ta win gan
du. ne. dei:
ba- ga- di. pa- ma na.
a pau&apos;
a- lu&apos; hpjei
na- poun: lein
dha- bjei njou jaun
ou za- na
da- ma.
mje&apos; jei le jwe:
kyoun za:
kin: ma. le&apos; me:
khwa bja
si&apos; pjan
za- dou&apos; hta.
nge gyun
lau&apos; thei
hsau&apos; khau&apos;
a- mje&apos;
ei&apos; tha mi&apos; hsa- ri. ja.
jei jwe&apos;
sa- jin: shin
kyo. shin:
shaun: shaun:
a- lun a- kyun
mje&apos; mhau&apos;
pjei bja&apos;
ma- ja:
no za pan:
ja- hain:
pa- lou&apos; kyin:
a: tin:
hswan: khan
ba- la bwe:
ba- zun chi gywei
tha: gyi: o: ra&apos; tha.
mi: ou&apos; hsaun:
a- nain lu.
pou: laun:
si: ka- re&apos;
lu mai&apos;
nei htwe&apos; ta- bju
mjin: pji&apos;
ei: gyan:
pju: ga- lu: pja ga- la
a- jaun jaun a- mha: mha:
a- kya nai&apos;
a- hswe
ji&apos; na&apos;
a- pjain: a- jain:
lhwa. hswe:
htou: dha:
shei: hpoun: shei: kan
ga- dein: ga- ba: hpji&apos;
nha&apos; hswe: bu:
kha- ji: ga- din:
pja&apos; tau&apos; pja&apos; tau&apos;
a- ljau&apos; ba dha
a- chein shi.
pan: zoun tha:
ja- khu. na.
ei&apos; me&apos; me&apos;
chin. wun
gin: ga
khwe: gya:
mein: ma. mhu.
ga hta
nji. ne&apos;
thwei: pjaun:
kha- ji: hpin.
than hsoun
chin: ja
a- jin: a- cha
ti: dou: pjo:
jei da- jau&apos;
a- dei&apos; be kau&apos;
za- la:
an: bji: nan: bji:
dha- din: mei:
ki lou mi ta
wu&apos; hsan hte.
lei te&apos;
tha- ma. bain:
a chau&apos;
le&apos; kha.
wu&apos; ju&apos; sin
thwe&apos; cha pa to: le
pjan. bjan. jan. jan.
jai&apos; che&apos;
a- hpou: chou
pjein: mje&apos;
hse&apos; sa&apos;
min: bau&apos;
the&apos; ma. cha.
le&apos; wa- zaun: khou&apos;
lu&apos; ja kyu&apos; ja
a- dun. shei
le&apos; pjan gyou: tou&apos;
a- houn
mje&apos; nha- hta:
sun dhou&apos;
htun: dun: pau&apos; pau&apos; hpji&apos;
kan. gyou&apos;
sa dan:
jin: mji&apos;
ou ba tain
tha&apos; in:
gwa. dou
ein daun dhe
ta- ja: dhu gyi:
tha ra- ka
pan kya:
a- khwin.
hsou&apos; jou&apos;
thi&apos; khe&apos; te:
da- ni. ta. e&apos; kha- ja.
hou&apos; la:
mjin gwin: gye
thi&apos; to:
lan: pwin.
a- tou chou&apos;
sin ne&apos; kha&apos;
mje&apos; ke: kha&apos;
lei&apos; pja sin
than dho.
ma- wu&apos; ja. da&apos;
hpjin po:
hti: di: gyi:
na- ji si:
pa- hsou&apos; pa- ni
za&apos; koun hpwin
jou: ze&apos;
mhan ba.
da- zein. zein.
nei win jou: ji
chau&apos; ka&apos;
tan lha&apos;
wan: dwin: gau&apos;
kyaun ba:
mai&apos; sa. toun:
bei an.
hsi: chou&apos; jo: ga
tha- mi: jau&apos; kha- ma.
kyei: dai&apos;
thain: gwe&apos;
poun: shou:
kyei na&apos;
jau&apos; ja pau&apos; ja
thoun: ze. ta- boun
le&apos; soun mou:
le&apos; lou&apos; le&apos; sa:
la- bain
ta- hpe&apos; lhe.
nein. ba:
bjoun: gyau&apos;
ta- jau&apos; da- bau&apos;
a- hpau&apos;
ba&apos; da. ga- ba
ne shin pe shin
da&apos; hsi in gyin
ja gin:
twei wei
oun: zan gyou:
ba- da:
hsei: gyau&apos;
wa- na
ma- ka.
loun: gyi: pau&apos; lha.
zi: gwe&apos;
thin ni: mha&apos; che&apos;
ka&apos; nji.
ta&apos; hpjau&apos;
a- chin thei&apos;
kyau&apos; sein:
a- khun a- tou&apos;
mje&apos; hsa.
a- li&apos; thou&apos;
san gyein tin
le&apos; hsa.
nga: za&apos; saun
jei mjaun:
ma- shu. ma- lha.
za- ga: sa- mji pjo:
thi la. kaun:
win: bau&apos;
a- htein: do
kwe&apos; kwe&apos; kwin: gwin:
di zin ba
a- bi
hpjei hsi
ba dho: nja dho:
the&apos; mwei: wan: gyaun: pjin nja
sa: gein:
bjaun kwe
kyei&apos; hsoun
jwa zou: goun:
kya- zu.
man da li
gaun: khan
le&apos; tou.
shwei din: ga: kye&apos;
toun: loun: lhe:
lu zu. khwe:
jei la mjaun: bei:
kyei: jwa ou&apos; su.
to: mhau&apos;
than kun gya
jou: jou: mha&apos; mha&apos;
pwe: u: dwe&apos;
hsi: kyou
e. wu&apos;
hsin hsa
a- lhwa a- lhwa
moun. gyu&apos;
a- shin
pji: pja&apos;
se&apos; jou&apos;
lan: pan:
htou: dou: htaun daun
tain kya:
ein da- rei kyi:
in: lai&apos;
a- kwe
kin njha&apos;
a- mai&apos; a- me:
pja. bwe:
sa pji&apos;
khi&apos; pjaun: to lhan jei:
taun dau ni i
ngan pja jei
le&apos; the: htou:
a- khwe: a- sei&apos;
pai&apos; htou:
an: ma- ja.
pou: kya.
kaun: za: jei:
jei ku:
nau&apos; hsoun: bo
aun mjei
koun: tin
a- ne&apos; pjan
a- than hpan: se&apos;
nei jin.
mou: bje: de
lu do
bei&apos; thei&apos;
jo: za- na
a- ju lwe
tha&apos; pin:
wun tin ta- rei&apos; hsan
thi&apos; tou
a- njaun: bjei a- nja bjei
a- kwei
tha ja zi:
thin ju
pjan kya: jei:
hpou: hpou:
mja- ma na ji
dha- bo: dhwa:
a- kin: tha&apos;
dha- bo: thei:
hpou tou sa- te&apos;
nhou&apos; kyou:
pa- lin khan
thei gyin pe&apos; kyi.
jin. kywei:
wei nei ja.
than wu&apos; ta. ka&apos;
le&apos; te&apos;
ga- za sha&apos; ta- ra.
hpjou khwin:
a- se&apos; a- pjau&apos;
ba- din: bau&apos;
nu. ne
ka- ma- htan:
mhu: gyi: ma&apos; ja
mje&apos; nha- chei
khwe&apos; saun: khou&apos;
hpa dha
khan chi.
bou gyou&apos; mhu: gyi:
mhan bju
lei nja
tha- main: gyaun:
zaun gyan:
ga- za
ju hsaun
kha- ji: twin
a- ta jei
bjaun du
goun: ma.
ba- du
nga- jan.
a- tu da- gwa.
mou: jwa
ta- htain de:
sa zaun
pan: ma.
a- hpo
kye&apos; sa
la&apos; ta- lo:
pjou kwe:
thu. da- ma za- ja&apos;
au&apos; chei lu&apos;
ga- za: khoun za:
kou dain jei: poun du
pa- lu tou
lai&apos; ljo: nji dwei
za&apos; mjo:
a- hsin tan za
sa&apos; thi:
chei zou&apos; le&apos; ne pju.
hsai&apos; hsai&apos; mjai&apos; mjai&apos;
nja. ta
bji. nhi&apos;
a- ti. za ta.
the&apos; njha
je&apos; pan:
wan: mjau&apos;
sha&apos; sha&apos;
le&apos; ja&apos; kho
a- kau&apos; njan
wan: ma- loun
jei dha khou
ka pjan
ga- za: bo
wei hin
jei lhwe: bau&apos;
a- kyaun: dhi.
pji&apos; si: pji&apos; jan
ga hta lai&apos;
tha- main: u:
sou&apos; pje:
haun haun kyi gyi
a- kye da- win.
je&apos; chou&apos;
hi ri. u&apos; ta&apos; pa.
a- mjein. dha:
cho: gyo: mo: mo:
oun: nhau&apos;
hpou lin ke:
thwei: dhau&apos;
a- htain kya.
khi&apos; nau&apos; kya.
a- mje: zein: to:
nwe gyou
a- mjin ka&apos;
a- shou&apos; a- htwei:
me: kya.
thoun: dha&apos;
de&apos; hti.
pwe: htein:
pin bju
a- nau&apos; mjau&apos;
nan zaun
bja. ga- dei.
ke: kyi.
sa- loun:
njan kaun:
a- lei: khou:
to: dha:
tha: a- mi.
the&apos; jin: ga- dou:
jan sa.
da- ba&apos; ji&apos;
sa gyan:
jei loun bjou&apos;
chi kan
je&apos; kan: gyou: mwei
oun: dhi: zan
kou&apos; chi&apos;
a- hsan: htwin
thaun tin:
in tin din
khun nha- than gyi hi&apos;
nei a:
o da
mai&apos; kan: gan:
ai&apos; sa&apos; sa&apos;
maun: le
ga- daun: kyai&apos; lou&apos;
mu ja ma ja
gye&apos; thi. le&apos; thi.
ou: bou&apos;
ta- ne mjei
a- ke: kha&apos;
a- hsei&apos;
nou. gyin
ou: gyan:
a- hsei&apos; te&apos;
ma din ga.
htoun: dan: sin la
than jan
za- ga: pa- lin khan
nga- hpe dei tei
thein ga- nei&apos; shwei
nau&apos; mein: ma.
a: a: ja: ja:
chin jan
mje&apos; tha:
pjou mji&apos;
thu gye&apos;
pin dwe&apos; pji&apos; si:
ka- lein gyoun
mhin nhei&apos; se&apos; ku
pe&apos; le&apos; ka- la- htain
ein dwin: na&apos;
pa- lo: pi nan
le bo zaun
dha- bin dhe
wu&apos; loun do ja.
joun: sai&apos;
mwei: njhin:
kye&apos; chi ga&apos;
a- dei&apos; be pau&apos;
chei khwin
dha- gya- khe:
hsei&apos; chi:
ta jou:
lhwa. daun
le&apos; mhan:
mje&apos; si. kyaun
shou&apos; shou&apos; she&apos; she&apos;
thi hou tha- je&apos; si.
nei. za:
joun. jin:
mou: zwei nghe&apos;
win: bain
a- sei. hpau&apos; pou:
a- khin: a- kyin:
ne&apos; than
mai&apos; loun: kyi:
thwei: jei gyi
a- kyi hsai&apos;
pan: jai&apos;
je mo:
chin gan
jau&apos; ko
ta- joun: joun:
jin gwe: za- ja&apos;
pa ra- mi hse ba:
bu: thwin:
shwei bo mja. din
ja- min:
mou: gya. la- hpe&apos;
u a- te&apos;
a- bi. ja za- ka.
an za doun:
da- ni.
nga- zin jain:
le&apos; tou le&apos; taun:
chei dau&apos;
wan: (wun:) hpo: wan:
hsin jan
hsei: dan:
a- hswe:
thi&apos; tau&apos; nghe&apos;
lai&apos; ka
man ma na.
htou: wa:
lei gin:
wa- loun: dou:
bu gaun
na- ba&apos; chin
a- hpan ta- le: le:
a- jwe hain:
tin: lin:
tha- mi:
sei&apos; zo:
a- lou&apos; htou&apos;
sei&apos; ma- shi. ba ne.
mju ni sa- pe
hswe: an
taun ta- le:
joun bwe:
a- twei: chu&apos;
pu&apos; tai&apos; a:
a- hpi:
le mjou
thai&apos; mjoun
a- twin: jei:
a- mje: dan:
mje&apos; si. than le
mau&apos; tin
bu: zin
htou&apos; hpo
lhwa gyin:
ja du: pjou&apos;
a- khwin. du: gan
a- chun a- te&apos;
mhe. sun:
le&apos; tin
a- sa. pjou:
nhi: gwe&apos;
pa- ra- bai&apos;
ga- ba pju mou:
mjei gyi:
hpji&apos; hsan: ga
a- chun
mjin: gyou:
le&apos; kau&apos; wu&apos;
pjaun: gau&apos;
a- hsaun mhu:
hsin na: za bau&apos;
ga- bja ga- thi
a gan du.
tha: di&apos;
hsaun jwe&apos;
maun: de&apos;
kyan zi
che ga ri
gaun: bju swe gyou:
da- li
ta- mu&apos;
tain bu:
a- jei&apos; a- mjwe&apos;
pou: hpa- lan
a. dha- di. tha. da na.
jan: ein
nan: jin: gwei
mje&apos; nha- bou: tha&apos;
sou&apos; sa. mjou&apos; sa.
a- hsa kye
nau&apos; hse&apos; twe:
ka la. thou&apos;
wu&apos; hsan ma.
ga- lan.
za- ga- ou:
na- gin:
ho: za
htei&apos; ka&apos; na
le&apos; pan: bau&apos; kha&apos;
kwe&apos; la&apos;
lei lwin.
pja: hpu&apos;
kya. hsin:
lei: bi nein
nhi&apos; sin gyei:
a- twin: lu na
chi bji&apos; le&apos; pji&apos;
a- shun hpau&apos;
a wei ni. ka. dou&apos; kha.
pjin: htan
da- ga- de: mha. be:
a- thwin: pji&apos; si:
mjei&apos; sou.
thwei: ei: dha- da- wa
a- pjei. a- wa.
hpji&apos; mje:
ou&apos; pa&apos; pjan
the bou:
lu ga- lei:
thi&apos; e
a- kyin. tan
le&apos; tha- ma: bau&apos;
an gyin:
a- na da- ja.
ta- ja. ja.
shin. nga- po:
a- kya&apos; twei.
pwei. oun:
ei&apos; hta joun
hswan: gyi: laun:
kyan hte&apos;
san gyein kyou:
su: zai&apos;
sei&apos; shou&apos;
kwe: bja:
a- hpan ta- ja
mou: gyou: dhwa:
wa- jan: htou&apos;
mha&apos; tha:
lu nei mhu. sa- ni&apos;
a- je&apos; ou:
dha- bo: pau&apos;
kha: jan: gyou:
ou&apos; sa shin
bjai&apos; to:
lhja&apos; si&apos; mi:
lu bo win
nga- hpaun jou: gyau&apos;
htou a- kha
a- hpwe. gyou&apos;
ka- la- ou&apos;
nei ma- hti. htain ma- hti.
gwa. ti: gwa. tai&apos;
sei&apos; hte&apos;
pa da.
kha- zi&apos;
wei ngha.
ma- ni.
thi&apos; te&apos; ngan:
khoun cha.
sa- ma- khan:
ein dhu ein dha:
hswan: ban:
ba- dei tha- ri&apos;
ha. gwe: hta- mein
mha&apos; kyau&apos; tin
pwe: zei:
a- chein bjei.
le&apos; gain:
a- hswei
chau&apos; loun: lhan. loun:
a- kyan
je. je.
hpe&apos; wun:
hsin bou:
da- ma. wa di
a- thi&apos; se&apos; se&apos;
nan: njun. nan: lhja
nga- hpan gwe&apos;
poun kya.
khwe&apos; htou: khwe&apos; lan ji
a- jin: dain:
hpje&apos; thin: bo:
kan: de&apos; thin: bo:
a- hpja&apos; a- ja
kyei: than da&apos;
pwei: zoun.
ka- ji. ka- hta.
lhwa. dhwa: hpo
nei lhan:
pa&apos; ma. loun: zoun
a- ke: ma- ja.
sei. zei. pau&apos; pau&apos;
jou&apos; loun: thwin: pjin nja
khwa lei&apos;
a- kyan dha- ma:
mji hse
jei: gwe&apos;
hpjei hsou
thi&apos; thi: wa- lan
mje&apos; nha- bjin
tha: tha- me&apos;
khan. nja:
mou: u: gya.
the&apos; nei wei:
lhei dha- gyi:
dou bi gya.
je&apos; kyaun:
mjau&apos; le&apos;
kyi: a dhi:
mjou: jin:
njan: hsin
da: jei:
tain ki
e: maun:
kyaun: bjei:
hsi: shwin
a- mwei: a- taun soun
pa&apos; wain: lhwa.
sha: bju
ba- du ba- jin
thein: hsi:
a- tain bin gan
pji dhu lu du.
si: zein shi.
nain gan do a- lan
ta- a:
kha- ri&apos; sa- ma&apos;
go ja hpjin
kaun: gyi:
a- ja dan:
pin le le&apos; kya:
ein. da- lein.
khin bou&apos; nghe&apos;
to: gwei:
a- pji: a- pain
le&apos; than pjaun
shei. zaun shei. jwe&apos;
a- khe: dha:
ga- lain
nhi&apos; thein.
jin. ma gyi:
nha&apos; chi:
a- ji wa.
pan: goun:
a- nhi:
po hsan: mhwei:
u. dhei: pau&apos; kin:
pou: mji mju:
mou: nhi:
a- lou pji.
pwe: htou&apos;
ja du: cha.
gyi&apos; pa- hsan
a- mhoun.
ka&apos; pi tan
chi ma- kain mi. le&apos; ma- kain mi. hpji&apos;
wan: ja: htou:
mjou: zin
min ga- la hsun:
pau&apos; pan: bju
pin le
hu dhi
po: lo:
hti. twei.
swe zoun kyan:
chwei: aun:
ka ki
bu. kya.
lu htwe&apos;
chi gyou&apos; mi.
jin ta- ma. ma.
a- ta te&apos;
u: baun:
ga- ba- jan
zaun: dan:
a- than pja
hsain goun
bjaun cho:
je: bo
a- ka. a- khoun
ke&apos; ein
nan. gyo: hswe:
shan: kha- mau&apos;
da&apos; lai&apos; thei
pou: daun ma
wu&apos; soun
nha- loun: jo: ga
hsi: za&apos;
ga- ra&apos;
gyan: doun:
lan: mhan kan: mhan
pjin: bjin: htan dan
nga- mjin:
pja. hsou gye&apos;
kan. gyou&apos; pja
tin. de
pou&apos; so nan
bou: ei
ta&apos; pjei:
paun: sa&apos; nan
za- na- ka za&apos;
dhou. hpji&apos; sei ga mu
tha&apos; ti.
a- htu&apos; a- mja&apos;
mje&apos; khoun: mwei:
thoun: bein: ka:
twin: aun:
nain ngan
nga- le&apos; khwa
lou&apos; li lou&apos; le.
mje&apos; nha ma- kaun:
nji nju&apos;
houn: soun:
mjei nan: do
hpo hsun
the: de: jei thun
kyan boun htou&apos;
lei&apos; kyau&apos; mhi:
pu: tha&apos;
te&apos; sei. le&apos; sei.
thwe&apos; cha pa da.
cho: sa:
le gyain.
wun: the&apos;
tha&apos; ba- ra. nan baun:
mei&apos; hswei
si: me. kan: me.
a- chan: te&apos;
si: kan: shi.
sa- jei:
ka&apos; na
pjin njha
soun zan:
gaun: na- ban: kyi:
jou: mha: gyo
chu&apos; cho
pa- chaun kya.
hpi. ze&apos;
htau&apos; hta:
a- kyi a- tha
doun: tai&apos;
a- tu. ma- shi.
pji dhu bain
shei: haun:
jei gyan:
hsou: nji
twe gyei&apos;
khou bja jaun
njhi. nhain:
se&apos; chou&apos;
moun dain
ka- nji&apos;
a- mji mhe.
goun ni ei&apos;
kya. lu
koun dhe lei
pja&apos; htan: gye&apos;
poun htoun:
chei gyin:
tha- hpjin.
nha chei
hpjou&apos; kha- ne:
mjain kya.
to: lai&apos; khwei:
a ju.
o tou ka- rei si
pjin gin:
wa zou hpa- jaun: dain
njin hei&apos; njin. nei
si&apos; hta na. gyou&apos;
min: na: pau&apos;
pou: soun: kyu:
a- su. shin
ga- di. ti
jo: sa&apos;
a- pji. a- soun
pan: dhei: khau&apos; hswe:
e: dhi
twei: to:
shwei sun njou ga- za: ni:
o mji
than lwin
shai&apos; pe&apos;
mjou: jei&apos; kha
hta- gyin.
ei kan
thein: htou&apos;
nain gan win gwin. le&apos; mha&apos;
khan: zi:
sei&apos; da- za. na
hpan ti hpan tu&apos;
pan kya: gye&apos;
a- le a- pa&apos;
i. ri. ja bou&apos;
pjei&apos; tha.
san htou:
mei: khain
nou kou u.
lhe: nau&apos; mi:
kwe htaun.
wun na. da. tha- ka.
khun: gyi: khun: nge pjo:
bi. la&apos;
to: jwa
mei&apos; tha- ha
pei an.
si&apos; u: zi:
mei. pjau&apos;
na- htein:
chi: mun: chei gyau&apos;
za- li hpa: doun:
goun khan
thou: ga- lei:
a- sun a- hpja:
gou&apos; thi: jai&apos;
kye&apos; te&apos; jei
tha- ma- ni. shei
da- gou jei da- ga ja.
a- si. ein
ha. hswe:
ma- ni. o: ga.
le&apos; thi: le&apos; maun: tan:
ti bou&apos;
htou&apos; chin: ga&apos;
a- tou: jin: bwa:
za- na- wa ri
htan: zo lei
jo: gi jaun
wi. za- jou&apos;
nga- lu:
ji. the. dhe.
gu. ta- lo:
khwin. pei:
a- ei&apos; hsou:
thwei: gyin: tha: gyin:
hpoun: lhwan:
hsi: chou&apos;
bain: daun.
a- kin:
hpa- la:
ba- hu. wou&apos; kein:
mhoun kou&apos; kou&apos;
pa&apos; wun: kyin
a- ti dhi:
da- na. tha- ha. ja.
gyo gye&apos;
na: shan
bju ha kyin:
ta- chi ta- maun: san:
bjoun: ga- ne:
u: zau&apos; gyun: bjan
nu. dwa:
shwei lan: ngwei lan: hpau&apos;
a- win hsou:
nei. gin: kyaun daun
lhaun gyain.
pei&apos; paun:
shi. ba zei
dan me.
hpa- je: u
htwe&apos; kha&apos; kha&apos;
a- pjaun tai&apos;
lhan zu&apos;
hte wa
a- chei
jo: be&apos;
jan: ga:
kyau&apos; chin
sein da- bo
a- kyan: kain
ba bu zaun
ka- nu. ka- ma
a- shin:
sa gyau&apos; jou&apos;
ei nu: na&apos;
a- chou&apos; kya.
nja. mhwei: ban:
u: pe. htan:
su: za:
mjei gwe&apos;
so: da- ka.
nei saun:
tin hse&apos;
hpa- bjan
wun: kyi:
a- ngan: ma- ja.
mou: jei
nga- pi.
pe&apos; le&apos; lan
baun win
a- lei pju.
sha hpwei jei:
ba- zun le&apos; ma. si
kye&apos; thi: mwei: njin: hta.
tou shei
lo: gyin:
hte&apos; laun. hte&apos; le:
zwe: gyou: cha.
kha- jan: gyu&apos;
a- kyo: pei:
nhou&apos; je:
wa- than ta.
dhou. hpji&apos; tho: gyaun.
ban: pa- jou&apos; hsi
me: khwe:
a&apos; hte
zin gyan:
na: ka- lo:
ei ka da. tha- ma.
hpi. a:
htin ja mjin ja
kha- baun:
a- shoun: khan
ba- zin: te&apos;
a- mi. nje:
chein. gyein.
a- ja&apos; pje&apos;
a- ne gya. kyau&apos;
a- ju: a- nhan:
da&apos; poun
lu. ni: ba:
da- bje&apos;
mhwei nhau&apos;
nain lun
bou&apos; ta- lou&apos;
sai&apos; kyi.
jou: jou: tan: dan:
dou&apos; kha. mja:
ka- jo.
goun tha&apos; ti.
ta&apos; mhu:
lein hpe be
lu wu&apos;
shan: baun: bi
ke&apos; ka- ru.
te&apos; nji le&apos; nji
thwei: hsoun:
kha- lei: le&apos; tun: lhe:
nan me zou:
mhji&apos; sou. bau&apos;
a- mo: hpau&apos;
koun pji si:
a- the: htei&apos;
le dhu ma.
za- ni: maun nhan
jei wun: be:
kun kha- nau&apos;
wain: do dha:
ba- loun
da- bou: doun:
gyou: ka&apos;
nu: na&apos;
nju hta- run
je&apos; soun tha&apos;
hsei: ku.
a- kyou: kyei: zu:
a- ta&apos; a- kya&apos;
a- tha: gin
a: du in mhja.
gyou zou: win
zei: kya.
kou kou:
nan nhein
kyan: ma jei:
dha- din:
mi: pau&apos;
ta- hsin. za- ga:
kaun: mwei hsou: mwei
le&apos; kya: jei jou
a- the: lhai&apos; u lhai&apos;
le&apos; hsaun htou:
zei: lai&apos;
za&apos; za- ga:
thu. wun na. tha ma. za&apos;
a- ti mhja.
tu ju
hswei wa:
nain gan wun dan:
nan nhei&apos;
hswei: mji.
nin be: nga- hsa.
dha- ga- ji&apos; te&apos;
hswei zin mjou: ze&apos;
jou&apos; chi:
mje&apos; mhan:
ga. gyi:
da&apos; sho:
na na&apos;
ba- zun
hpou: wa. jou&apos;
a- mjou: a- mji
pa- le:
kau&apos; ti
nga- zein: dhe
khwe: sei&apos;
jwei. sha:
kou pu
a- mhu. a&apos; ma-
ka- ru. na
ja- dhei:
be&apos; pjaun:
lo: ka. wu&apos;
a- ke: kain
a- na: ba&apos;
du: dain sai&apos;
ba. la- chai&apos; lai&apos;
tan gyi&apos;
dei than da- ra. ba- hu. thu. ta.
a- thei zou:
a- kwe a- ka
kyau&apos; jei
a- lou&apos; thin
a- nu. pjin nja
taun dan ga- dou:
mhaun khou
hsa- ji&apos; wain:
a: khe:
da&apos; tain
nga- hpjan
ga- di. khan wun gye&apos;
mje&apos; si. ta- mhei&apos;
ne nhin
houn: houn: tau&apos;
lu: dwin:
kyaun: a&apos;
pe: kya zan
pa- jou&apos;
lain nou
nau&apos; hpei: thwa:
kan zou: mou: mhaun kya.
khou: dha: da- mja.
pjaun kain:
a- sa. chi
a- wei&apos; za
ngan: tai&apos;
nja. u: jan
bain: gaun: kyau&apos; hpi.
le&apos; twin:
nga- sein
nha jei
kha- de&apos;
nga- hpaun jou:
jei gyaun: bja.
the&apos; thei lai&apos;
mou: gou dha:
kyei chan:
ja&apos; ti gye&apos;
a- na jin:
thoun: bau&apos;
lu mhan: ma- thi.
a- ju wa da.
ka- ja: jei bei&apos; za- ga:
jei dein
tha- je: gyi:
nau&apos; kyaun: pjan
khin dei&apos;
jei bjin
a- kyan: be zi.
le&apos; mou:
thi&apos; toun:
kye&apos; taun zi:
ka- le&apos; te&apos; te&apos;
u doun the: doun hpji&apos;
kou&apos; chaun: gyaun:
kau nga- lei:
a- thoun: a- swe: kyi:
mha&apos; che&apos;
hti. aun
htan: hpu:
u: zi:
poun zan htou&apos;
jwa. bou: htou:
paun: joun:
mi: se&apos;
kyei: pa
tun ji wu&apos; soun
pwei. pai&apos;
mou: khaun
a- tha- ma
a- kyin: daun
jou&apos; soun sin
bo gyo.
pa- rei&apos; nei&apos; ban san
a&apos; tha- kan taun
tan swe&apos;
sa hpa&apos; pa- jei&apos; tha&apos;
mje&apos; twin: hau&apos;
ma- lhan: ma- kan:
a- sun: jau&apos;
min: dha- gyi:
maun: dan
hin: cha.
bju rou ka- rei si
pe ri sa- kou&apos;
ga- ju. pju.
lein: zei:
jei bjan
thein ga ra. ra. tha.
pain: wei
htan: loun: bjau&apos;
hsa- ja lou&apos;
kyei: naun
mi: tin: gou&apos;
au&apos; lhu&apos; to
a&apos; kwe&apos;
pau&apos; ga- nan:
ta- i. i.
tain: gyei pji mji&apos;
lu ja- da&apos;
le gya
na lou khan khe&apos;
pji. da- za
man nei gya
mwei zein:
je: gyou&apos;
a- hpou: tan
mjei boun hpa- ja:
pau&apos; pan: zei:
za- le&apos; ta
nga- mji&apos; chin:
mi: gyo
kha- lau&apos; hswe:
ma- thi. dha: hsou: wa:
se&apos; hsan
sin: za:
kye&apos; sha
kin: lu&apos; koun
pa- rou gye&apos;
kywe&apos; mi:
jaun. te&apos;
a- hse&apos; a- thwe
pa- lin
thei: pau&apos;
a- che&apos;
kyau&apos; kyi:
ga wun
ze&apos; tha&apos;
a- na. ma- te&apos; ga.
a- nei ka. thin cha
mwei: kyei: zu:
mje&apos; daun.
tin kyou
su. paun: le ja
a- we dain
sein jei gwe&apos;
lei htou:
zei: kho
tou: lou: tan: lan:
kun: i&apos;
sa di: mhu: gyou&apos;
hsan pja
shein: pi:
le&apos; dha- gywe
nhin: ga in: gyi
thi: nin.
pji daun zu. nei.
sa. dhi
we&apos; ma- lu&apos;
a- njhou: thou
shei dou: nau&apos; hsou&apos;
thoun: nhoun:
than ljin:
sin: nhi doun:
a- the: na
mjou: dou: mje&apos; te&apos;
jan: daun.
a- khun
kou han pja. me
jei wei
na- hpa: bau&apos;
ka- njin zi dain
na- zun za- hpja: kya:
pa- la ta
a- khan. thin.
lu sai&apos;
gaun: zi: gaun: gain
jai&apos; ja
kha- jo kha- ju&apos;
mo lei&apos;
wu&apos; kyin:
ke&apos; ku. zu:
thau&apos; sa:
mwei: le&apos; mha&apos;
ga- bai&apos; hsaun ta&apos;
njan ni njan ne&apos;
to: mi:
ko ma- shin
ta- ja:
than dei ka la.
so: da- ka. te&apos;
mjou: gya:
pe: ba- zun
thei: dwin:
za- ga- gyi: za- ga- gye
hsei&apos; kan:
sai&apos; pjou:
ga- wun jou&apos;
a- khwa.
chwe: jain zei:
jun kyau&apos;
hpwe bwe ja ja
khun: toun. pjan
kya ka- la&apos;
hsan: pja:
chei&apos; hswe:
kyo: mwe:
le sin: khan
lu mhan: thu mhan: ma- thi.
ba- dau&apos; pa- ji&apos;
than gyou: jai&apos;
a- chein me
mou: tein dai&apos;
wi. thei tha. le&apos; kha- na
ti gein:
a- lan bja.
hpjou: bjou: hpja&apos; hpja&apos;
htei ra. wa da.
pou: na- ga:
pein: ne: bjin
hpa- jaun: wa:
le&apos; pei: tha&apos;
hpja&apos; lan:
pa- khoun: htan:
mi: htou:
di jei
le&apos; kain ei&apos;
nau&apos; jau&apos;
naun kyin
so: da- na
ba- za&apos; pou&apos;
che&apos; kha- ne:
pwa. bau&apos;
dha- di. cha&apos;
ta- ja- ma. gyaun:
mje&apos; kwe pju.
ma- sin
ga- za: za- ja
hpja&apos; than:
u. pe&apos; kha
nei zwe
me: chau&apos; chau&apos;
bu ri. da&apos; za&apos;
we&apos; ju: na
kyun: mjo:
a- ti&apos;
a- kyi:
a- hpou: lei:
a- hso
ju: thu&apos;
thwei: tha: kaun:
a- the&apos; hse&apos;
shwei mhau&apos;
a- kain a- twe
joun: dhoun: wo: ha ra.
laun: dan:
poun ma- kya. pan: ma- kya.
cho le: jo: htain
sa pei lou&apos; tha:
jei goun
pji&apos; zu
hta- njha&apos;
se&apos; to ja
a- nau&apos; jan:
han lhwe:
hwi: ga- ne:
khan mjou.
se&apos; mhu. pjin nja
a- shin dha:
sa: u: sa: bja:
tha- min ga- lei:
ho: he:
thei: dhwe
ja du:
hpa: ja:
sa: ein thau&apos; ein
khwe&apos; poun: dha- ma:
hi na. ja na. gain:
ka- lan
mhi njou:
ka- thain: wun:
pji: zi:
ka- ji: ka- hta. mja:
jo. ba:
khwei: za: we&apos; sa:
kha- ji: hsan.
mjin: thi la
gan hti.
kaun: gaun: kan: gan:
sa: thoun: goun
tan htwa
thu nain nga njhin: lou&apos;
za rei&apos; ta.
chi zou&apos; le&apos; ne pju.
mja. lu
jin kyei:
a- hsin: tun:
kyou. gyou. jou. jou.
da: hte&apos;
ta&apos; khin:
a- hpjaun.
da&apos; tha- na. pjin nja
nei ja&apos;
hta&apos; kein: njhun:
hswei mjou: nja ti.
u ja: hpa: ja:
we&apos; u sou&apos;
wi. ni: shaun
lan: mja:
bei: dou: jin gya&apos; na
shei. jei: nau&apos; jei:
ma: ma: ja&apos;
nga- jou&apos; hsi
u. ba- dei gyan:
le&apos; ga- do. tin
ka- ri.
than bjain
sain jo
gyi o: mei tri
hswan: do din
pjou: htaun
kyan hsa.
si&apos; tan: htou&apos;
a- ju khan
pa- lin bau&apos;
nan: tin
pa&apos; tu
htu. khwe:
lin bjo: tha: bjo:
gyaun htou:
woun: ga- ne:
a- hti: kyan
a kye a- wun:
kyau&apos; hsi&apos; jou&apos;
hsa&apos; hsan
sei&apos; than
pei: a&apos;
chi: mun:
kye&apos; u.
pi na&apos;
kan da.
than mhjo.
pju. za:
mhjau&apos; chei
lei njin: khan
jou&apos; shin min: dha:
mou: se:
a- ngai&apos; hpan:
to: gya. hse
te&apos; lhan:
ga- dau&apos; ga- hsa&apos; hpji&apos;
tha- ba pa- ti.
jein: jain
do: hta.
gein mhan
na. gan: ta- loun: mhja. ma- thi.
ja za- wu&apos; kaun
kaun si&apos; wun joun:
mjin: wun
in ma- ti. in ma- tan
mou: nhaun: hse
nei goun nei gan:
ou&apos; htou&apos; hsaun:
a- si&apos; a- kyo:
gwa. kya.
ta- man: hswe:
za&apos; pou.
shwei da- min:
a- mho
sa- hwei.
ou: na- dou
ne gan
chwei: than
ta- htei ja di:
a- ke ti.
ein: i: ma- lou&apos;
pan: ta- mo.
chi wi nu bau&apos;
goun ban
goun pju.
ma- to
lo: ka. gyaun:
ta&apos; hpjan.
tha- ou&apos; ma.
la. ga. za:
jun: i&apos;
chein gwin
pa- mou.
ji&apos; tan
a&apos; chou&apos; hsain
pan: go bi
hsin. bwa: a- ne&apos;
kau&apos; nge
a- kyo: tin
nga- ljin mha&apos; se&apos;
jaun jan:
mje&apos; si. jin
a- nu. zei:
ne: ba:
naun da. ja.
hpjoun: za&apos; kyou
le&apos; htei&apos;
ta- ja: ja.
hta&apos; kein: jin:
shei. hsaun
lei htou: dan
le&apos; hpji&apos;
hsoun: shoun:
pji&apos; chwe:
jaun. je:
tha- khou: thei bo njhi.
jan man
kye&apos; hsu zi
ka- la:
kya&apos; ti: mjei
ho: kya:
hsou jou: za- ga:
shwei gyou
lei: be&apos; thwa:
kan: kou naun
chou: hpau&apos;
htin: khwei
lin: zwe:
jou&apos; njan.
than bou than ma.
a- tou: gyi: sa:
a- mhu. lou&apos;
la- mje&apos;
joun: bjin ka- na: jau&apos;
a: ne:
zei: po:
mhjau&apos; kein:
a- pjin:
ja. gyou: na&apos;
mja&apos; le:
chei ma.
hto: ba&apos; thi:
le gya
tha: de&apos;
da- za
a- the: khai&apos;
wa- hpaun
taun goun:
le&apos; kain shi.
pou&apos; hsan:
ou&apos; o thaun: din:
ba- gan dou na
kun ga- re&apos;
mo gun: htou:
a- chin: pwa:
hpju ga pja ga
kho: za
khe&apos; ma.
khwin. thwa:
pja gwe&apos;
lei: njhin:
toun: maun:
a- lou shi.
pu tin:
hsi gyan jei gyan che&apos;
ban la&apos;
nou. bwei:
a- than o: za
kyin: mjaun:
pja&apos; tha:
pa- jan
shei: u: dhin
ne&apos; hpjan
mhi njan: pju.
kyain lhain
kain: bju mi:
jan htaun
kyan: gyou&apos;
da- ma. du ta.
mwei: gyu&apos; na
a- mu gun:
lhan. loun:
hpou&apos; pu mi: dai&apos;
htan jin:
mein: ma- njan
dha- di. mu
wa: ba- jaun:
shwei ba- dein
a- me lei:
hsun: do tin
jain: pja.
kyu&apos; kyu&apos; lu&apos; lu&apos;
pwin. zan
u. di:
jein gou&apos; thin: bo:
pa- ra- mei
a- nu. lo: ma
wan: zwe:
thu&apos; pja:
kyi ga&apos;
sei&apos; ku:
than chi gyin:
du. jin
i&apos; au&apos;
pa- lou&apos;
mje&apos; nha- lou mje nha- ja.
nhei&apos; kye dhi:
kyein za tai&apos;
kyei: le&apos;
ba. ba. gyi:
cha: pou&apos;
ka- ma- zei&apos; di.
sa- mou&apos;
ka- la- hpju
ou&apos; nhe:
o di ka- loun:
ei: ei: hsei: zei:
nha- kyei&apos; shi&apos; hsu bwe:
pjou: gin: gyu&apos;
su. zu. baun:
ga du:
lun: tin
mji&apos; ta le&apos; hsaun
pu. pja&apos;
noun: chi.
mje&apos; nha ou
ta- ja
dha- dei dha:
hin: za:
lou&apos; za- ga:
jaun gyi do
lhe: jin
sa zi&apos;
hpan gye&apos; se&apos;
ke&apos; pa- tein
a- the&apos; sei.
thwei: zei:
za- bin hsou: zei:
than gyou gain
kyo: bu gaun: bu
pji: hsoun:
wa- loun: dau&apos; khoun
le zi.
na- ga:
la. mai&apos; je&apos;
gai&apos; tan
au&apos; shin:
a- mjaun
mje&apos; khoun:
nau&apos; pei&apos; hpa- na&apos;
tha- mou.
ga- bja
than ta. ra. tha.
a- ljin mi
dha- boun dha- gan
a- sou: ja. kei&apos; sa.
ba- ja na- ka. ja. tha.
maun: ma.
pju&apos; tan
rwain je ti
hsi ljo daun.
ke. je.
hti pau&apos; sin
chein se&apos;
kywei ban:
pwe: za:
a- mjou: dha- mi:
mje&apos; si. kwe ja na: kwe ja
jo. ji. jo. je:
pa- khe&apos; twin: a- jwe
a- ji aun
gyau&apos; pau&apos;
a- ji&apos; gya.
hta- njhin: gwin:
hpa- bjou&apos; jei na
na&apos; kun:
ja. aun
thin. tin.
si: bwa: sha
a- shin ma:
lei: loun: lei: be&apos;
do: hpaun:
khwei: dau&apos;
nhain: chein
lein hpe
hswei: nwei:
a- thou&apos;
nei bu lhan:
je&apos; kan: kha&apos;
hu dha- mhja.
kyi: ta ja
a- kwa a- wei:
ji njhun: gye&apos;
kou dwei.
bji&apos; tau&apos; bji&apos; tau&apos;
a- ngan
hsou&apos; kain
gye&apos; sei. le&apos; sei.
thou&apos; chei tin
htu. pi. ka
ba- zaun
oun: lei: be&apos; khaun
ei ka nei ka.
kha&apos; chou
hpa- ja: a- jei do
poun zan
a- haun:
pjan. mhwei:
a- khan. dha:
koun a- mha za
a- dha- gya.
ja- man zan
mje&apos; si. su:
a- lhwa
a- jou: a- jin:
thei dha&apos;
nha- ma.
au&apos; tou ba
ma- ni. u: bji:
a- kyaun: pja.
lwin ti: gaun
nhan: ba&apos; kyau&apos;
than ga do
za- le: hto
a- chou&apos; hse
za- ga: goun
nau&apos; ma- ja:
mjei ga- dou&apos;
ka- nju&apos;
pa- lu: pa- le:
nei mjin la. mjin
hta. ka: ja: htain ka: ja: ne.
la. zou&apos;
nhaun. nhei:
tho: ta.
mhjo lin. gye&apos;
a- njho
to do
lin: nou. chi:
a- ja do
boun dau&apos;
u: htei&apos;
ja- han: laun:
a- htu: ta- le
hin: lin: bjin
mi: bou
baun: do
si&apos; than mhu:
kyou: gyou: kou&apos; kou&apos;
khan. za
gin dei&apos;
hsei&apos; sa
nhi: gau&apos; hpja
shwei jei:
bei: hti.
chaun: ngin
pa&apos; tou&apos;
hpoun: kwe
gya: hpja&apos;
me&apos; gin
za- ga- za. mja:
a- jou: a- sin
mu. ni.
a- htou&apos;
dha- bjei ban:
mei: jou:
lhja&apos; si&apos; da&apos;
sa- chin. pjan
du: chaun
a- twin: wun
kei&apos; sa wei&apos; sa
sei: pain
bei: ti:
a- bein njin
chei zoun pji&apos; win
sei. za&apos; kyaun: lan: gyin:
nga- je: ou:
au&apos; so nan
pa- ji&apos;
dha- ba wa.
hpau&apos; ei&apos;
le&apos; saun.
gun: ga&apos;
ba- hou zi
le&apos; shaun
ga- dou&apos; kyin:
ja dhi se&apos;
choun: bwe: cha. ngou
nei. zwe:
kyo: khain:
le&apos; hwei.
ja&apos; hsain:
mou: kya.
je&apos; ma. shou
nan: hsan
lei&apos; ta
ou&apos; ta- ra than
jei zi&apos;
pe: gyi: khun tun.
hsin: je:
chi njaun: le&apos; hsan.
a ka
njin: zan
mi: gou: kywe&apos; shau&apos;
da- jou:
ba- wa. haun:
da&apos; khan
than da ge:
bwe. lun thin dan:
za- ga: mja:
cha&apos; mein njou
a- lin:
poun khain:
tha- hau&apos; tha- he&apos;
a- hsou: kya.
lu mjou: gwe:
mho aun
pji&apos; pji&apos; kha ga
ga- lan. cha.
chein hsa.
chu: pai&apos; hsan
a- mein. za
ma- chu&apos;
a- pjaun
a- lin: pau&apos;
sei&apos; pjei le&apos; pjau&apos;
mjin: ma.
mji: du: jou:
je&apos; kan je&apos; kan
ta- ja- khwin
jwa dan: shei
thin: dhi:
gan da&apos; ba.
bu: mhjo:
nhan: hpju:
ga- dou. zei&apos;
sei&apos; lai&apos; man ba
lei mwei. ja
san: pwin.
nain ja za:
ni ta je:
pji jei: pji ja
kou du:
lu gyi&apos; lu gin po:
ba- rou kei&apos;
lu gyi: soun ja
khaun jan:
htwei dwei le le
le&apos; pan:
a- chein bain:
nha mhou&apos;
o: ka tha. lo: ka.
khou nan: gyou:
a- tei&apos;
wun hsaun
htin mjin
maun: gyau&apos;
hsan kyin ta ja
mu mhan
kau&apos; lhain:
zei: ga- za:
hsin: bu.
ma na- wi
bjaun kya.
nha- pa: zoun
htou&apos; hsaun
kyou: gain
hpaun: gan
lu wu&apos; le:
hpoun: do gyi:
hsaun: mji: na
a- jai&apos; a- ja
min zu tha- ka.
ne lu.
mjei daun mhjau&apos;
na&apos; nou: la.
mi: gwin:
a- le
lhu bwe wu&apos; htu.
thin: bo: hsa- bou&apos;
ma- nou&apos; tha. bei da.
zun: gyi&apos; oun:
ka ma.
hsu: daun
ba- zun zi
a: te&apos;
tun. lei&apos;
da- bou: gyi:
ka- na- zou:
a- ku
a- kha kya: a- mjau&apos;
moun ji&apos;
pwe: ja.
tha&apos; ba ja. hpji&apos;
kha- naun:
tha- nge do jou&apos;
ma- hsi&apos; hsi
a- lei: gyein
tha wa- ka.
an zaun
nau&apos; hta.
a ra- ha&apos; ta- me&apos;
woun: woun: dain: dain:
bwa: bwa:
nei hti: hsaun:
a- kyo: mhjin
hpaun: bjin:
je: njun.
a mei dei&apos;
mau&apos; ru
bein: chi:
mwei ba- da:
kyi gyi shwin shwin
ta- oun nwei: nwei:
a- lan jai&apos;
ja&apos; thi. jwa dhi.
mou: the&apos; moun dain:
na- dha
tho: ga:
than daun
nei bu sa&apos; kha:
hpan ba- dain:
mje&apos; sa. mje&apos; na.
nga. shin
a- kyin. pa
jau&apos;kya- dhu
oun: hto: ba&apos;
kyaun: hta:
a tei&apos; se&apos; wain:
mje&apos; wu&apos;
chou tha
hpin da- gywa. gywa. hpji&apos;
jei gyou koun
lo: ba.
za- ga: nha- khwa. pjo:
ba dha pjan
a- kha. za: win
a- ke:
twe&apos; si&apos;
pei&apos; thin: ga&apos;
nhou&apos; mei: gun:
hpe jan:
ja- za wu&apos; thin.
kyi bja jaun
a ka tha. pwin.
na- gyi gaun
lei jin gwin:
... jou: ... sin
ka&apos; hpou ka&apos; ma
a- jaun din
kan bain
thi&apos; si: kain
da- gun dain
khwin. lhu&apos;
dha- da pau&apos;
hsin ga&apos; le
a- mu a- ju
a- pjo: a- ho:
koun khan:
ba- gan
jei zein kywe:
mje&apos; twin: kya.
jei mha&apos;
chei ba- mje&apos;
si: tha:
hin: gywei:
a- chain. dha:
ba- lu: gyein:
hsou: jwa
kha- na ban:
mein: ma- dein:
jou&apos; shi.
sin: za: gan: win
tain tan:
goun ji
a- kyaun: sha
san pe
khou: kyi.
mi: a ma. gan
a- khe: ma- kyei
le jain:
a- ngha:
gyu&apos; hsa&apos; hsa&apos;
u. bou&apos;
da-ra&apos; sin
hse&apos; khan
na&apos; ga- do
than jou&apos; bji:
dei&apos; dei&apos; kye:
than ke&apos; ku zu:
wa- zi gan
sei&apos; hsaun
a- ke da- mi
dha- di. mei.
pe: di bin bau&apos;
pju. lou&apos;
koun gyau&apos;
ma- gyi&apos; u.
ji: di: ja: da:
a- mu: dha- ma:
a- mhja. pjei:
da- ma- u: gya. mjei
koun nga.
zei: kaun:
pe be ne ne
zei: gyou
a- kyaun: ma- lha.
hsa- ne
dha- da bjan
thwa: du.
wa- ba&apos;
dha- din: mhwei:
mi: win mi: dwe&apos;
chwei: thei&apos;
ba&apos; la&apos; kya.
pjan dan: khan
a- tou. a- htaun
sa- chin. bwe
thein hpjin:
pjei. kya&apos;
kyi: ni
a- thoun: sa- jei:
a- jaun hsaun
nan ba&apos; kou naun
te&apos; te&apos; sin
ti daun
moun. bain: daun.
lei&apos; kyau&apos; mi:
ga- di. thi&apos; sa pju. bwe:
tha: je: ta- rei&apos; hsan
tin ba- hsoun
kei ti. ka ti. lou&apos;
mou&apos; hsou:
le&apos; khou&apos; le&apos; wa: ti:
hsou: wa:
a- ne: ne. a- mja:
kyau&apos; mje&apos; ja- da- na
me: hsan da. ne
le&apos; oun dha:
ba- da na. kya.
dau&apos; ja&apos;
kha- ji: lun
sain: nhin
ta- aun. ta- na:
na- than dhi:
sha gyi
lu lu&apos;
a- mi: sa: be&apos; gaun: sa: be&apos;
joun: dwin: sa
su: zu: jwa: jwa:
ma- ga- da. ba dha
kha- jei bwin.
kya thin gan:
njhun kya: gye&apos;
le&apos; sa. kyi:
dhou. ga- lau&apos;
hpe&apos; le: da- gin:
lwan: hsu&apos;
tu ma.
nga- ne:
a- mje: a- swe:
pji bu.
a- me min:
tha: dhe a- mei
bein du.
lu dhwe&apos;
jo. ne:
a- nou&apos; a sou&apos;
me: ne
nje&apos; njo:
nei. le za
hpoun: hsou: do:
le&apos; lun
bein njin:
kha- ju. dou&apos;
toun doun jin jin
hpjan. bju:
a- than
lwe ku
mo: ha.
ta lu. za.
tha- ra- ze
hswei ni: mjou: za&apos;
a- hpjo
kye&apos; khu&apos;
a- ja a- htaun
ma- tha- di
kyei: mi: bou
u. ba- ba&apos;
pa&apos; ta- la:
u haun: laun: hpji&apos;
khau&apos; ga- din
tha: gyi: nga: gyi:
jaun: jin
than ga zin
zwe: hsu.
nge zin taun gyei:
a- hsaun a- jwe&apos;
a- khou:
pan: le dain
a- she&apos; khwe:
le&apos; pja&apos;
kou lu&apos; le&apos; lu&apos;
au&apos; hswe:
lu gyi: mi. ba.
a- loun: a- hpan
le&apos; jei&apos; pja.
aun. i:
mjei gan
wa- bou: mje&apos; hsan gye
jwe du dan: du
ka gwe jei:
nan me hwe&apos;
shi lin
a- thoun: kya.
jo: ja
sou da- ga- bei&apos;
lhe: dhan
hpu: za hsoun
kya: gya: ja: ja:
ou: dan
mhjoun: paun: le:
a- kyi.
a- hti.
ma- gan:
tha- ra- na- goun thoun: ba:
na: pji jou
di mou ka- rei si
poun zan dou&apos;
ma- ha bju ha
le&apos; an thei
mo: mu ha. da&apos; tha- ka.
ko: za gyou
da- zei. da- zaun:
thi ta.
hsou: tei
tha du. kho
ou&apos; hpa- na&apos;
nan me ta&apos;
tha- he:
pa- li zi. chau&apos; che&apos;
hsa&apos; koun:
po: dho:
lou ta. ja.
kou bain
na- ban:
a- ljin a- mjan
lin: we&apos;
te&apos; ka. bei da.
ngan: mwei
ta ba&apos; kwin:
a- kwe: a- sha.
chei gyin: lein
a- tin. je:
ja za- wu&apos;
mje&apos; si. shan
pjau&apos; kwe
be: daun
htu: zan:
chin dhei.
wa dha- na pa
kun: dhi: bin
la-jin: ba:
lei gyou thwei:
na- bu: lein
lou&apos; kwe&apos;
tha- ra- na- goun tin
a- jei: hta:
be&apos; lai&apos;
la- da. mhain mhain
thi&apos; htwin: ba- gyi
zi za- wa
hsain: nau&apos; hta.
poun wu&apos; htu.
ma- jan: jaun
mjin. mja&apos;
njein: ei:
pa- hta- ma- nge
a- soun a- soun
joun: kan
a- hsin.
nha- khan: kwe:
wa hpa&apos;
ka- lun daun
da- bje&apos; si:
kha- ji: gyan:
si&apos; ta- lau&apos;
a- jou a- thei pei:
se: ze:
lei dhan
dha- bu&apos;
a- kho a- wo
nga- man: zwe
da- gau&apos; kwei:
twin goun
a- mjin kye
thei gya ga. na.
lan cha:
ka- li. jou&apos;
je&apos; hte
u zoun the: zoun
ba- lu: zwe.
a- ju: a- mai&apos;
kau&apos; nhou&apos;
hpan mi: ein
hpji&apos; sin
se&apos; kya.
u kyaun gyaun hpji&apos;
ba- nan:
mjei we ma- kya.
ou&apos; sa- ju:
njhou zain
hta- ji
kou dain kou gya&apos;
kan gaun: htau&apos; ma. lou.
pa- ti pe&apos; kha.
zei: baun gyou:
ou: khwe:
tha- je&apos; pa- ni
za- gwe:
gau&apos; kwin:
da- ha&apos; tha- gain:
win goun
daun sain:
ta wei
dhou. hpji&apos; lhjin
mhan gwe&apos;
mjau&apos; jaun: ma.
hpoun: gyi: kyaun:
hpan tou. dan:
ma- nhi&apos;
na: sai&apos;
mjou. do wun
da ji. ka ma.
jei gyou
le&apos; jan: le&apos; hsa.
tha: lhi: da:
jei dwin:
mi: boun bwe:
a- ju: chi: ban:
lei gyin
mjou. gan
hpin mje:
moun. thi&apos; ta
wa hta&apos;
a- loun: zei:
o. nha- loun: na
pa ja. zei
nan nge bain:
wa- thi bo
a- me
mji nwa:
dha- din: gaun: zin
kya: ma.
ka- ne&apos; ga- dan
nou. ngha
lei: gin:
hti. ba:
an zwe:
pa&apos; shau&apos;
tha- ma- jou: gya.
le&apos; khe&apos;
jei chou: zei&apos;
kin: mi: gau&apos;
bou&apos; da. tha dha- na
shu. ti di
kyin be&apos;
i&apos; za&apos; ta.
an zoun:
jou si:
ta- mjin: kha&apos;
than shei
je: din:
dha- dei pa
pai&apos; da- min:
ga- za:
na ga- ri
choun khou tai&apos;
sei&apos; ku: sei&apos; than:
poun: ji taun za
za- bu pa- ni
man: mhou&apos;
hsa la ei&apos;
kha le
hpe: thei
ein daun pju.
chei gyo le&apos; gyo
cho le:
ta- kha de:
lhei gyi: dou: jou: jou:
khe&apos; khe:
kyi. di. kyaun daun
sa- tu. ma- ha ri
jin: nhi: mhjou&apos; nhan
jan: zein:
ka- htein
hpa- lan
mjou: ze&apos;
goun pa- ka tha- na.
chin: ta.
da- ga:
njou: njou: njei&apos; njei&apos;
a- pjou a- jwe
a- sun: a- sa.
dha- ga- la&apos;
ra tha. sa pei
da- bwe: dou:
hsun: gan pin.
mi: ge: pja boun:
ba- bu.
kwa ha. gye&apos;
sei&apos; da- za. nan
je: ta&apos; hpwe.
a bo
da&apos; bu:
jei bjin nji mjin:
jei htou&apos; mjaun:
jei mhoun jei mhwa:
ta lhu&apos;
lo: kyan:
a- mhu. dan: sa ou&apos;
njan do
chou chin
a- mhu. dwe: htein:
hpjei: bjei:
lai&apos; pjei:
tin: dein
a- lein ma thoun:
loun: bau&apos;
a- chou&apos; a- lou&apos;
a- mei: a- mjan:
lwan: bja: lwan: na kya.
pju. mu
lu. je&apos;
mje&apos; mhaun kyou&apos;
kha- ji: kyun
poun zan gwe&apos;
mje&apos; twin: chaun
ga- ba lo: ka.
shun. nun
au&apos; kyou.
hpa- jaun: pa- hsou:
jei zi
tha: gaun
da- ba&apos; shou
sein ni mjin: dhwa:
a- khou: tha&apos;
lou&apos; kain
ou&apos; khoun
thei: pan:
pwin. thi&apos; sa.
tha- min dhwei:
mje&apos; si. pja
so ga:
hpa- ja: pja.
sei lhu&apos;
ngan pja. bja.
me: kyou&apos;
a- jou: gan
tha- htei:
tai&apos; jei jin
ne: mja: ma- hsou
hsi zei:
kye&apos; jou: htou:
ei ga- mou&apos; oun:
nwan: ji.
oun: mhou&apos; ta- jo:
a- the: gyo
tha&apos; da. ni. ke
na- sha gyi:
si&apos; mhi:
hsan mhoun.
jaun: we hpau&apos; ka:
a- chi: za- ga:
da- zi:
tha- chin: dha:
te: dha- lei&apos; hswe
a- mha&apos; ja.
pjei. nhe&apos;
loun: loun: khe: ge:
kyun: gau&apos; nwe
sa- jwei:
lin na- min
mje&apos; ji&apos;
shwin shwin pjoun: bjoun:
khan. nja:
a- tha: hsaun
jou: jou:
ei&apos; hsaun
khou ka&apos;
u: zaun njhun kya: jei: mhu:
thwei: te&apos;
njhin: loun:
hpwe. gyou:
nan. dha ni
pjei njein:
ta- nei. ga.
koun zi pja. bwe:
nei ja cha.
jei ga- do.
poun: kwe
wu&apos; le
a- lein a- nja
bjoun: za: bjin: za:
nhou&apos; kyin:
a- mwei:
ka- lo tou&apos;
pja: jei
pja dhei&apos; mou:
da- ra- ho:
ma. a:
ti bi
sa mu gyan:
thwei: si&apos;
nga- bjan
kha- lei: pje&apos;
che&apos; chin: le&apos; ngin:
a- mhu lou&apos;
chin twe
lu zoun te&apos; soun
si&apos; pjei:
pou&apos; ba. na- mei&apos;
le&apos; pjin:
te&apos; ga- zi:
khwei: zwe:
pjou&apos; pjou&apos; bjoun:
si&apos; si:
mjou. ja nin:
njein zein
ja za. da ni
ei ga- mu
hpau&apos; the zei:
wei&apos; pa&apos; ti. ta- ja:
kyi. bjo shu. bjo
min: dha- gyan:
pu: baun:
ou&apos; sa:
kha: na
e&apos; si&apos;
ja&apos; kyi: dha:
kyi. chwe.
hswan: thu&apos;
dha- bei&apos;
jei wei koun: dan:
a- tan: a- sa:
ba bu
kye&apos; paun zei:
ka- li ka- ma lou&apos;
nhaun: da- gu:
pan: dou&apos;
na- bin: dain
mwei: za- jin:
pi bi pjin bjin
mi: bu
hsou: dhwan: lu nge
kye&apos; mi.
twei. kyoun
pin. the&apos; shu
ta&apos; htein: gyou&apos;
wa- ja: mhau&apos;
hsaun: khou
thin: bain
ja&apos; sun jwa na:
pein chi.
pu&apos; su:
jou jwin:
nga- mjin: ou&apos; hpa:
zei: hswe:
hi&apos; tain
nga: mhja:
gan da- ma
in pji:
thu ta- khun: nga ta- khun:
ma- hti
sein: za: u.
daun gya sain:
pa&apos; ma.
pjin dha lei&apos;
wun le&apos;
hswe: ngin a:
hsin chi: doun: hsa&apos; pja
jei ja
wan: ne: pe&apos; le&apos;
pa- ma da.
gi&apos; lhei
na- mu: na- htain:
a- sa jei za
ju&apos; na:
shu: tai&apos;
hpjan bjei
thu. min ga- la. du. min ga- la.
pwe: wain:
kya bju
nge dhan pa
nge zei&apos;
ka jein da-
ban: tin
a- dei&apos; be shi.
dain khan
pa- htwei:
lu loun: pja.
a- laun: a- sa:
pa- ti. zi wa. hsei:
lei: tin
lei tha- la&apos;
pou&apos; e. e.
nain gwe&apos;
a- thi.
kan: jou: dan:
dha- bo.
ta- me gaun:
nga- gyin: gwe&apos;
a- mhoun a- mhwa:
a- sein: gyo
sun gou&apos;
ou nau&apos;
mi: bja. dai&apos;
sei&apos; pain: hpja&apos;
lu&apos; la&apos; jei: mo gun: win
dha- din: zoun
gyou htaun
dha- ga- ji&apos; shei
sa- ne mjei
lei hsan
a- mha&apos;
kye&apos; tha:
hsi: aun.
bu: dhi: gyo
le&apos; pje&apos;
oun: nhau&apos; shin:
gyou te lu:
le&apos; hpji&apos; ti:
a- kha tha- ma- ja.
jan zwe ne. ngo: ngo:
chei zi&apos; pwe:
a- tain a- to:
kyei: zu: kan:
hpau&apos; su:
a- ne hta.
jo: ha- ni
ka- mau&apos; ka- ma-
ka- ma kyi
a- na jin:
le&apos; kyo: tin:
le&apos; wa- zaun:
koun bou&apos;
da- be.
than gyi:
ma din ga. mho
jau&apos; chou
a- ja&apos; tha:
a- kwe&apos; sha
me: kyo:
a- jei a- jaun
je&apos; tou thin dan:
mje&apos; nha- gye&apos;
chun: ma.
pai&apos; wun: bu
lu dha:
ba. dwei:
lu mwe:
nei pu gan dhi:
mjei nji da&apos;
na- ju ba- dei dha.
a- hpou: ou
na mji gan
thu do thu mja&apos;
hpjei. bju:
e. jei&apos; tha
ei&apos; poun:
thin tha- ka- rai&apos;
wi. ni: dou
jo zwa
ga- dwin: shin:
a- ngan:
le&apos; kyin.
shei: ba- wa.
chin zi
pjaun shu&apos; shu&apos;
poun nei: ma.
man: jein gan: jei
a- ja
na- bin:
win jou: zun: dei tha.
pa- thain: mwei:
ze tau&apos;
lain sin khan
thi: dhan.
ei ga- bai&apos;
doun: ti. di.
jan: jo
hse jei: ta- jei: kou: jei: ta- ja
twe&apos; hsa.
kha- le gaun
sun je:
pin mhe.
mje&apos; nha pje&apos;
na&apos; tha- mi: kan: ba:
a- mhin
po htwe&apos;
pan: ou:
wa- bou:
kin: boun:
thei na gaun
ga- do. zun:
ta- ja- win
joun bain
hpa: gu:
sun daun hswe:
ou: dein: ze&apos;
kyei: zu: shin
