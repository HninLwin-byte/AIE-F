# Assignment 6 — Statistical Machine Translation for Burmese G2P

## Overview
Phrase-Based SMT system for Burmese Grapheme-to-Phoneme (G2P) conversion.
Trained using Moses SMT framework with MGIZA alignment on the myG2P corpus.

## Folder Structure
- Data/            — Raw g2p-par corpus (train/dev/test, .my and .ph files)
- Clean_Data/      — Escaped and syllable-normalized data with SGM files
PBSMT & PBSMT_Nomalize are large files: therefore please access through the following drive link
https://drive.google.com/drive/folders/1Cj_GBo2tp0emiLN1yh1dTH12j8MuMi0E?usp=sharing
- PBSMT/           — SMT experiments with normalization (Baseline, Exp2, Exp3, Exp4)
- PBSMT_Normalize/ — SMT experiment without normalization (Exp5) for comparison
- Syl_Normalizer/  — Burmese syllable normalization tool and dictionary
- Notebook/        — Kaggle Jupyter notebooks for baseline and experiments
- Report/          — Full project report (.docx)

## Results Summary
| Experiment          | my->ph | ph->my |
|---------------------|--------|--------|
| Baseline (5g,p5)    | 69.82  | 78.08  |
| Exp2 (3g,p5)        | 69.57  | 78.11  |
| Exp3 (3g,p3)        | 69.61  | 78.28  |
| Exp4 (3g,p3,noprune)| 69.87  | 78.58  |
| Exp5 (no norm)      | 69.20  | 78.39  |

## Best Configuration
3-gram LM, max-phrase=3, no pruning, with normalization (Exp4)
- my->ph: 69.87 BLEU
- ph->my: 78.58 BLEU

## Tools Used
- Moses SMT (compiled from source)
- MGIZA (multi-threaded word alignment)
- GIZA++ (word alignment)
- syl_normalizer.py v0.6 (Burmese syllable normalization)
- Kaggle Notebooks (x86-64 Ubuntu 22.04)

## References
- myG2P corpus: https://github.com/ye-kyaw-thu/myG2P
- Moses: https://www.statmt.org/moses-release/RELEASE-4.0/binaries/
- Tutorial: https://github.com/ye-kyaw-thu/AIE-F/tree/main/slide-code/class-13and14
